"""
model/model.py
--------------
SLMModel and SLMForCausalLM — the full model registered with HuggingFace.

SLMModel: the core transformer (embeddings + decoder stack + final norm).
SLMForCausalLM: adds the language model head and loss computation.

Design:
    - No bias anywhere
    - Pre-norm throughout
    - KV cache support for efficient autoregressive generation
    - Compatible with HuggingFace generate(), trl, lm-evaluation-harness, vLLM

Important implementation detail:
    SLMModel is a plain nn.Module.
    SLMForCausalLM is the only PreTrainedModel.

This follows the standard HuggingFace architecture pattern used by Llama,
Mistral, GPT-NeoX, Phi, etc.:

    SLMForCausalLM(PreTrainedModel)
        └── SLMModel(nn.Module)

Only the outer class calls post_init(), so initialization and HF
save/load behavior are controlled from one PreTrainedModel.
"""

from typing import Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import PreTrainedModel, initialization as init
from transformers.cache_utils import Cache, DynamicCache
from transformers.generation import GenerationMixin
from transformers.masking_utils import create_causal_mask
from transformers.modeling_outputs import BaseModelOutputWithPast, CausalLMOutputWithPast

from .attention import RotaryEmbedding
from .block import SLMDecoderBlock
from .config import SLMConfig
from .norm import RMSNorm


LegacyCache = list[tuple[torch.Tensor, torch.Tensor]]


class SLMModel(nn.Module):
    """
    The core SLM transformer — embeddings, decoder stack, final norm.

    Does not include the LM head — use SLMForCausalLM for language modelling.

    Important:
        This is intentionally a plain nn.Module, not a PreTrainedModel.
        The outer SLMForCausalLM owns HF initialization, saving, and loading.
    """

    def __init__(self, config: SLMConfig):
        super().__init__()
        self.config = config
        attention_implementation = getattr(config, "_attn_implementation", None)
        if attention_implementation not in (None, "sdpa", "flash_attention_3"):
            raise ValueError(
                "SLM supports attn_implementation='sdpa' or 'flash_attention_3', got "
                f"{attention_implementation!r}"
            )
        if attention_implementation is None:
            config._attn_implementation_internal = "sdpa"
        if attention_implementation == "flash_attention_3" and config.attention_dropout != 0:
            raise ValueError("FlashAttention-3 requires attention_dropout=0; select SDPA to use attention dropout")

        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList(
            [SLMDecoderBlock(config, layer_idx=i) for i in range(config.num_hidden_layers)]
        )
        self.norm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.rotary_emb = RotaryEmbedding(config)
        self.gradient_checkpointing = False

    def get_input_embeddings(self) -> nn.Embedding:
        return self.embed_tokens

    def set_input_embeddings(self, value: nn.Embedding) -> None:
        self.embed_tokens = value

    def _convert_legacy_cache(self, past_key_values: LegacyCache) -> DynamicCache:
        if len(past_key_values) != len(self.layers):
            raise ValueError(
                "Legacy past_key_values must contain exactly one entry per "
                f"decoder layer: expected {len(self.layers)}, got "
                f"{len(past_key_values)}"
            )

        cache = DynamicCache(config=self.config)
        for layer_idx, layer_cache in enumerate(past_key_values):
            if not isinstance(layer_cache, (tuple, list)) or len(layer_cache) != 2:
                raise ValueError(
                    "Each legacy cache entry must be a (key, value) pair; "
                    f"invalid entry at layer {layer_idx}"
                )
            cache.update(layer_cache[0], layer_cache[1], layer_idx)
        return cache

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, LegacyCache]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[BaseModelOutputWithPast, tuple]:
        if (input_ids is None) == (inputs_embeds is None):
            raise ValueError("Specify exactly one of input_ids or inputs_embeds")

        if use_cache is None:
            use_cache = self.config.use_cache and not self.training

        # Fixed-length pretraining/evaluation batches contain no padding mask,
        # no cache, and use the default monotonic positions. In that exact case
        # both attention implementations express causality directly. Avoiding
        # create_causal_mask() here prevents torch.compile from materializing a
        # dense 4D mask solely because the model is being traced. Any caller
        # that supplies a mask, positions, or cache keeps the general path.
        use_implicit_causal_mask = (
            attention_mask is None
            and position_ids is None
            and past_key_values is None
            and not use_cache
        )
        # Default monotonic positions need no packed-sequence inspection in FA3.
        flash_position_ids = position_ids
        if output_hidden_states is None:
            output_hidden_states = self.config.output_hidden_states
        if return_dict is None:
            return_dict = self.config.return_dict

        if self.gradient_checkpointing and self.training and use_cache:
            use_cache = False

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)

        if isinstance(past_key_values, list):
            past_key_values = self._convert_legacy_cache(past_key_values)
        elif past_key_values is not None and not isinstance(past_key_values, Cache):
            raise TypeError(
                "past_key_values must be a Transformers Cache or a legacy "
                f"list of key/value pairs, got {type(past_key_values).__name__}"
            )

        if use_cache and past_key_values is None:
            past_key_values = DynamicCache(config=self.config)

        if self.config._attn_implementation == "flash_attention_3":
            if attention_mask is not None and attention_mask.ndim != 2:
                raise ValueError("FlashAttention-3 requires a 2D padding mask; select SDPA for custom 4D masks")
            if past_key_values is not None and past_key_values.is_compileable:
                raise ValueError("FlashAttention-3 uses DynamicCache; select SDPA for a static cache")

        past_seen_tokens = (
            past_key_values.get_seq_length()
            if past_key_values is not None
            else 0
        )
        if position_ids is None:
            position_ids = (
                torch.arange(
                    inputs_embeds.shape[1],
                    device=inputs_embeds.device,
                    dtype=torch.long,
                )
                + past_seen_tokens
            ).unsqueeze(0)

        if use_implicit_causal_mask:
            causal_mask = None
        else:
            causal_mask = create_causal_mask(
                config=self.config,
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                past_key_values=past_key_values,
                position_ids=position_ids,
            )
        position_embeddings = self.rotary_emb(inputs_embeds, position_ids)

        hidden_states = inputs_embeds
        all_hidden_states: list | None = [] if output_hidden_states else None

        for layer in self.layers:
            if output_hidden_states:
                all_hidden_states.append(hidden_states)

            if self.gradient_checkpointing and self.training:
                hidden_states = self._gradient_checkpointing_func(
                    layer.__call__,
                    hidden_states,
                    causal_mask,
                    position_embeddings,
                    None,
                    False,
                    flash_position_ids,
                )
            else:
                hidden_states = layer(
                    hidden_states,
                    attention_mask=causal_mask,
                    position_embeddings=position_embeddings,
                    past_key_values=past_key_values,
                    use_cache=use_cache,
                    position_ids=flash_position_ids,
                )

        hidden_states = self.norm(hidden_states)

        if output_hidden_states:
            all_hidden_states.append(hidden_states)

        if not return_dict:
            return tuple(
                value
                for value in [hidden_states, past_key_values, all_hidden_states]
                if value is not None
            )

        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=past_key_values,
            hidden_states=all_hidden_states,
        )


class SLMForCausalLM(PreTrainedModel, GenerationMixin):
    """
    SLM with a language modelling head for causal language modelling.

    This is the only PreTrainedModel in the architecture. It owns:
    - initialization via post_init()
    - standard save_pretrained() checkpoint serialization
    - tied embedding behavior
    - HF generation compatibility

    Checkpoint loading uses the native PreTrainedModel.from_pretrained() path.
    Weight initialization must therefore use transformers.initialization helpers:
    they preserve tensors materialized from a checkpoint while still initializing
    newly constructed models from scratch.
    """

    config_class = SLMConfig
    base_model_prefix = "model"
    supports_gradient_checkpointing = True
    _supports_sdpa = True
    _supports_flash_attn = True
    # Match native Llama's compile contract. The forward path is static for
    # fixed-shape pretraining and contains no data-dependent Python control flow.
    _can_compile_fullgraph = True
    _no_split_modules = ["SLMDecoderBlock"]
    _skip_keys_device_placement = ["past_key_values"]

    _tied_weights_keys = {"lm_head.weight": "model.embed_tokens.weight"}

    def __init__(self, config: SLMConfig):
        if getattr(config, "_attn_implementation", None) == "flash_attention_3":
            # Require the installed FA3 extension before Transformers can try
            # a Hub kernel. Import failures must not select another backend.
            try:
                import flash_attn_interface  # noqa: F401
            except ImportError as exc:
                raise RuntimeError(
                    "FlashAttention-3 requires the source build installed by make setup-train"
                ) from exc
        super().__init__(config)
        self.model = SLMModel(config)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self._fused_linear_ce_loss = None
        self._fused_linear_ce_enabled = False
        self.post_init()

    def enable_fused_linear_cross_entropy(self) -> None:
        """Enable Liger fused LM-head + CE for loss-only pretraining calls."""
        try:
            from liger_kernel.transformers import LigerFusedLinearCrossEntropyLoss
        except ImportError as exc:
            raise RuntimeError(
                "fused_linear_cross_entropy requires liger-kernel from "
                "requirements-training.txt"
            ) from exc

        # Use sum reduction and normalize explicitly so Trainer's
        # num_items_in_batch contract is identical to Transformers'
        # ForCausalLMLoss. Liger remains responsible for chunking the
        # vocabulary projection and avoiding the full [B,T,V] logits tensor.
        self._fused_linear_ce_loss = LigerFusedLinearCrossEntropyLoss(
            ignore_index=-100,
            reduction="sum",
        )
        self._fused_linear_ce_enabled = True

    @torch.compiler.disable
    def _fused_causal_lm_loss(
        self,
        hidden_states: torch.Tensor,
        labels: torch.LongTensor,
        *,
        num_items_in_batch=None,
        shift_labels: Optional[torch.LongTensor] = None,
        ignore_index: int = -100,
    ) -> torch.Tensor:
        if not self._fused_linear_ce_enabled or self._fused_linear_ce_loss is None:
            raise RuntimeError(
                "loss-only fused pretraining was requested before "
                "enable_fused_linear_cross_entropy()"
            )
        if ignore_index != -100:
            raise ValueError(
                "fused pretraining currently supports ignore_index=-100 only"
            )

        if shift_labels is None:
            padded = F.pad(labels, (0, 1), value=ignore_index)
            shift_labels = padded[..., 1:].contiguous()
        else:
            shift_labels = shift_labels.contiguous()

        flat_hidden = hidden_states.reshape(-1, hidden_states.shape[-1])
        flat_targets = shift_labels.reshape(-1).to(hidden_states.device)
        loss = self._fused_linear_ce_loss(
            self.lm_head.weight,
            flat_hidden,
            flat_targets,
        )

        denominator = num_items_in_batch
        if denominator is None:
            denominator = flat_targets.ne(ignore_index).sum()
        if torch.is_tensor(denominator):
            denominator = denominator.to(device=loss.device, dtype=loss.dtype)
        return loss / denominator

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        # Keep native HF loading (including tied weights and loading_info).
        # Only derived RoPE state is repaired after materialization. In
        # particular, do not call model.init_weights() here.
        result = super().from_pretrained(*args, **kwargs)
        model = result[0] if isinstance(result, tuple) else result
        rope = model.model.rotary_emb
        device = rope.inv_freq.device
        if device.type == "meta":
            device = model.model.embed_tokens.weight.device
        if device.type == "meta":
            raise RuntimeError("RoPE must be materialized on a real device after loading")
        rope.reset_parameters(device=device)
        return result

    def _init_weights(self, module: nn.Module) -> None:
        """
        Initialize weights with config.initializer_range.

        This runs on every submodule when post_init() recurses, including
        modules inside SLMModel. SLMModel intentionally does not define its
        own _init_weights; this is the single source of init policy.

        Use Transformers initialization helpers rather than direct ``.data``
        writes so native loading can preserve already materialized checkpoint
        tensors while initializing only the modules that still require it.
        """
        std = self.config.initializer_range

        if isinstance(module, RotaryEmbedding):
            module.reset_parameters()

        elif isinstance(module, nn.Linear):
            init.normal_(module.weight, mean=0.0, std=std)
            if module.bias is not None:
                init.zeros_(module.bias)

        elif isinstance(module, nn.Embedding):
            init.normal_(module.weight, mean=0.0, std=std)
            if module.padding_idx is not None:
                init.zeros_(module.weight[module.padding_idx])

    def get_input_embeddings(self) -> nn.Embedding:
        return self.model.embed_tokens

    def set_input_embeddings(self, value: nn.Embedding) -> None:
        self.model.embed_tokens = value

    def get_output_embeddings(self) -> nn.Linear:
        return self.lm_head

    def set_output_embeddings(self, new_embeddings: nn.Linear) -> None:
        self.lm_head = new_embeddings

    def get_decoder(self) -> SLMModel:
        return self.model

    def set_decoder(self, decoder: SLMModel) -> None:
        self.model = decoder

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, LegacyCache]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        logits_to_keep: Union[int, torch.Tensor] = 0,
        materialize_logits: bool = True,
        **kwargs,
    ) -> Union[CausalLMOutputWithPast, tuple]:
        if labels is not None and use_cache is None:
            use_cache = False
        if return_dict is None:
            return_dict = self.config.return_dict

        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_hidden_states=output_hidden_states,
            return_dict=True,
        )

        hidden_states = outputs.last_hidden_state
        loss = None
        logits = None

        if labels is not None and not materialize_logits:
            if logits_to_keep != 0:
                raise ValueError(
                    "logits_to_keep cannot be combined with materialize_logits=False"
                )
            supported_loss_kwargs = {"num_items_in_batch", "shift_labels", "ignore_index"}
            unsupported = sorted(set(kwargs) - supported_loss_kwargs)
            if unsupported:
                raise ValueError(
                    "Unsupported fused pretraining loss kwargs: "
                    + ", ".join(unsupported)
                )
            loss = self._fused_causal_lm_loss(
                hidden_states,
                labels,
                num_items_in_batch=kwargs.get("num_items_in_batch"),
                shift_labels=kwargs.get("shift_labels"),
                ignore_index=kwargs.get("ignore_index", -100),
            )
        else:
            slice_indices = (
                slice(-logits_to_keep, None)
                if isinstance(logits_to_keep, int)
                else logits_to_keep
            )
            logits = self.lm_head(hidden_states[:, slice_indices, :])
            if labels is not None:
                loss = self.loss_function(
                    logits=logits,
                    labels=labels,
                    vocab_size=self.config.vocab_size,
                    **kwargs,
                )

        if not return_dict:
            output = tuple(
                value
                for value in [
                    logits,
                    outputs.past_key_values,
                    outputs.hidden_states,
                ]
                if value is not None
            )
            return ((loss,) + output) if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
        )

    def _reorder_cache(
        self,
        past_key_values: Union[Cache, list[tuple[torch.Tensor, torch.Tensor]]],
        beam_idx: torch.Tensor,
    ) -> Union[Cache, list[tuple[torch.Tensor, torch.Tensor]]]:
        """
        Reorder KV cache for beam search.
        """
        if isinstance(past_key_values, Cache):
            past_key_values.reorder_cache(beam_idx)
            return past_key_values

        return [
            (k.index_select(0, beam_idx), v.index_select(0, beam_idx))
            for k, v in past_key_values
        ]
