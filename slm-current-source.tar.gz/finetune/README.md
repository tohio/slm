# Supervised Fine-Tuning

This directory prepares external instruction datasets and trains the instruct,
code-instruction, and optional raw code-completion branches.

Synthetic example generation is maintained in
[`tohio/slm-synthetic-data`](https://github.com/tohio/slm-synthetic-data);
this repository consumes datasets but does not generate them.

## Contents

| Path | Purpose |
|---|---|
| `configs/sft_data_sources.yaml` | Pinned dataset, adapter, limits, and validation policy |
| `configs/sft_instruct_*.yaml` | Instruct SFT recipes |
| `configs/sft_code_*.yaml` | Code-instruction SFT recipes |
| `configs/code_completion_*.yaml` | Optional raw code-completion recipes |
| `data/prepare_sft.py` | Normalize, validate, deduplicate, split, and manifest SFT data |
| `data/prepare_code_completion.py` | Derive leakage-checked completion pairs |
| `train_sft.py` | Assistant-only-loss instruct/code trainer |
| `train_code_completion.py` | Prompt-masked raw completion trainer |

## Model branches

```text
pretrain/final
  └─ sft_instruct/final
       ├─ dpo_chat/final
       └─ sft_code/final
            └─ sft_code_completion/final  (optional)
```

Instruct SFT starts directly from the pretrained base checkpoint, with learned
embeddings and weights preserved. Code SFT starts
from instruct SFT so it retains the general assistant behavior learned by the
first stage.

## Dataset contract

`configs/sft_data_sources.yaml` is the source registry used by preparation and
training:

| Stage | Dataset | Adapter | Full-profile cap |
|---|---|---|---:|
| Instruct | `HuggingFaceH4/ultrachat_200k` | conversational messages | 50,000 |
| Code | `ise-uiuc/Magicoder-OSS-Instruct-75K` | problem/solution instruction | 75,000 |

Each source is pinned to an immutable revision. The 125M, 350M, and 1B
profiles use the same selected population; `mini` uses 1,000 records per
stage for pipeline validation.

Preparation writes:

```text
$DATA_DIR/runs/<size>/sft_instruct/
  train.jsonl
  val.jsonl
  manifest.json

$DATA_DIR/runs/<size>/sft_code/
  train.jsonl
  val.jsonl
  manifest.json
```

The preparation stage normalizes records to the project's conversation
schema, validates required roles/content, rejects excessive invalid or
duplicate rates, and splits by normalized user prompt. The manifest records
the source revision, selection settings, file hashes, record counts,
retention statistics, and zero prompt overlap between train and validation.
Existing output is reused only when its manifest matches the current contract.

## Prepare data

Prepare both SFT stages:

```bash
make prepare-sft SIZE=125m
```

Prepare or replace data explicitly after changing the source contract:

```bash
python finetune/data/prepare_sft.py \
  --size 125m \
  --stage both \
  --force
```

SFT preparation validates/splits text and does not require a tokenizer or apply
a token budget. During training, the input checkpoint supplies its bundled
tokenizer and chat template; TRL performs length filtering and assistant-mask
construction. Cross-size pretraining already copied the source tokenizer into
the base checkpoint, so no model-size tokenizer fallback is needed.

## Train

Generate hardware-specific recipes on the training host:

```bash
make config-gen-sft SIZE=125m GPUS=1
```

Train instruct and code branches:

```bash
make sft-instruct SIZE=125m GPUS=1
make sft-code SIZE=125m GPUS=1
```

Resume the latest compatible checkpoints:

```bash
make sft-instruct-resume SIZE=125m GPUS=1
make sft-code-resume SIZE=125m GPUS=1
```

Run preprocessing and compatibility checks without optimization:

```bash
python finetune/train_sft.py \
  --config finetune/configs/sft_instruct_125m.yaml \
  --preflight-only
```

The trainer requires the tokenizer chat template and its generation markers.
It applies assistant-only loss, reports retained/supervised tokens, enforces
the configured minimum retention ratio, validates context and vocabulary
compatibility, and keeps packing disabled so examples cannot attend across
packed boundaries.

Before Trainer construction, training verifies the manifest's own checksum,
stage/size, complete file hashes/counts, and normalized train/validation prompt
separation, before any `max_samples` selection. A fresh run records an immutable
`sft_run_audit.json`; resume compares config, architecture, parent config/weights,
tokenizer/template, data, and process count before accepting the latest numbered
checkpoint. New runs cannot overwrite occupied outputs. Preflight uses temporary
Trainer output and never replaces an established run audit.

The promoted `final/` directory contains the lowest-validation-loss checkpoint,
its actual tokenizer/template, the run audit, the prepared-data manifest, and
the portable `training_provenance.json` ancestry bundle:

```text
$RESULTS_DIR/runs/<size>/sft_instruct/final/
$RESULTS_DIR/runs/<size>/sft_code/final/
```

For interrupted-run preflight add `--resume` (optionally followed by an explicit
checkpoint path). Missing recovery state is rejected; see
[recovery requirements](../docs/TRAIN.md#recovery-checkpoint-completeness). Older post-training audits without
an immutable contract cannot be used to assert safe resume. See
[training identity and compatibility](../docs/TRAIN.md#post-training-identity-and-resume).
Trainer state/logs, not a rewritten run audit, record best-checkpoint metrics.

## Optional raw code completion

Derive completion examples from the already split code-instruction dataset:

```bash
make prepare-code-completion SIZE=125m
make sft-code-completion SIZE=125m
```

Preparation preserves parent split membership: validation comes only from the
original held-out code-SFT file. A small nonempty holdout is kept; an empty one
fails instead of borrowing examples the parent model already trained on.
`stats.json` binds output files to the parent train/validation file hashes.
Training verifies those hashes against the parent code-SFT manifest/audit.

This optional single-process trainer masks prompt tokens, uses token-weighted
validation loss, writes recoverable checkpoints, and promotes the best validation
checkpoint to:

```text
$RESULTS_DIR/runs/<size>/sft_code_completion/final/
```

Resume directly:

```bash
python finetune/train_code_completion.py \
  --config finetune/configs/code_completion_125m.yaml \
  --resume
```

Recovery stores the epoch and next-batch cursor alongside optimizer, scheduler
and Python/Torch/CUDA RNG states. Each epoch's permutation comes from an
independent seed-based sampler, so restarting an iterator cannot repeat or skip
the remaining examples or perturb dropout RNG. The raw run audit is immutable;
resumes verify recipe, prepared data, parent identity and tokenizer. Tokenizer
files are loaded from recovery and preserved without rewriting the vocabulary.

With `save_best` enabled, each recovery directory contains a verified `best/`
snapshot for that step. This requires additional model storage, but prevents a
later best-model update from invalidating an otherwise complete recovery.
Resume restores the run's mutable best model from that snapshot; copying only
`training_state.pt` is insufficient. To rewind, move later checkpoints aside
explicitly; saves do not overwrite existing numbered directories. Legacy raw checkpoints without a
cursor cannot provide exact continuation and are rejected. Legacy preparation
without `validation_origin=parent_val_only` must be re-prepared. These restrictions
do not delete or modify the old artifacts.

This optional branch remains a local completion experiment; it is not a fifth
production export variant.

Evaluate the branch with HumanEval:

```bash
make eval-code-completion SIZE=125m
```

HumanEval executes generated code; run it only in an isolated environment.

## Validation

Run contract and one-step integration tests before a full job:

```bash
python -m pytest \
  tests/test_sft_data_contract.py \
  tests/test_training_args.py \
  tests/test_trl_smoke.py \
  -q
```

Validate completed stage artifacts:

```bash
make test-sft-instruct SIZE=125m
make test-sft-code SIZE=125m
```

## Optional tool-use conversations

`prepare-sft` accepts `SFT_TOOL_DATA=/path/to/reviewed-tools.jsonl` and merges those
instruct examples before the existing grouped prompt split. The same SFT trainer
handles assistant requests, tool results, final responses, and no-tool examples.
Only the rendering template is updated; the vocabulary and embeddings are not
resized. See [tool data and runtime](../docs/TOOL_CALLING.md) for format, illustrative
examples, provenance, and limitations.
