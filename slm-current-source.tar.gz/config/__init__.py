"""
config/
-------
Shared configuration for the SLM training pipeline.

This package is the single source of truth for values referenced across
multiple stages (data curation, pretraining, SFT, DPO, export, notebooks).
If a value exists here, no other file should hardcode it.

Organising principle: if changing a value would break a locked contract
(data mix, token budgets, tokenizer special IDs, shuffle RAM budget, etc.)
it belongs here. If it's a stage-specific tuning knob (SFT learning rate,
DPO beta, eval few-shot counts) it belongs in the stage's own config.
"""

from config.data_mix import (
    # Data mix
    DATA_MIX,
    CODE_SUBMIX,
    OVERFLOW_SINK,
    SUPPLEMENTAL_CHAR_CAPS,
    SYNTHETIC_PRETRAIN_DOC_CAPS,
    NON_CODE_SOURCES,
    CODE_SOURCES,
    ALL_SOURCES,
    SYNTHETIC_SOURCES,
    FILTER_SOURCE_FAMILIES,
    PROSE_HEURISTIC_SKIP_SOURCES,
    LONG_DOCUMENT_SEGMENT_SOURCES,
    DEDUP_PRIORITY,
    # Token targets
    TARGET_CONFIGS,
    # Curator constants
    CHARS_PER_TOKEN,
    CC_CHARS_PER_SEGMENT,
    SHUFFLE_RAM_BUDGET_GB,
    PRETRAIN_VAL_FRACTION,
    SMOKE_OVERRIDES,
    # Helpers
    dataset_link,
    corpus_tokens,
    consumed_tokens,
    corpus_tokens_display,
    epochs,
    source_filter_family,
    validate,
)
from config.benchmarks import (
    BENCHMARKS,
    LM_EVAL_DECONTAMINATION_NGRAM_SIZE,
    LM_EVAL_REVISION,
    LM_EVAL_VERSION,
    benchmark_decontamination_contract,
)

__all__ = [
    "DATA_MIX",
    "CODE_SUBMIX",
    "OVERFLOW_SINK",
    "SUPPLEMENTAL_CHAR_CAPS",
    "SYNTHETIC_PRETRAIN_DOC_CAPS",
    "NON_CODE_SOURCES",
    "CODE_SOURCES",
    "ALL_SOURCES",
    "SYNTHETIC_SOURCES",
    "FILTER_SOURCE_FAMILIES",
    "PROSE_HEURISTIC_SKIP_SOURCES",
    "LONG_DOCUMENT_SEGMENT_SOURCES",
    "DEDUP_PRIORITY",
    "TARGET_CONFIGS",
    "CHARS_PER_TOKEN",
    "CC_CHARS_PER_SEGMENT",
    "SHUFFLE_RAM_BUDGET_GB",
    "PRETRAIN_VAL_FRACTION",
    "SMOKE_OVERRIDES",
    "dataset_link",
    "corpus_tokens",
    "consumed_tokens",
    "corpus_tokens_display",
    "epochs",
    "source_filter_family",
    "validate",
    "BENCHMARKS",
    "LM_EVAL_DECONTAMINATION_NGRAM_SIZE",
    "LM_EVAL_REVISION",
    "LM_EVAL_VERSION",
    "benchmark_decontamination_contract",
]
