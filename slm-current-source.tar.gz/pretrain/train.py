"""
pretrain/train.py
-----------------
Pretraining entry point using HuggingFace Trainer.
"""

import argparse
import json
import hashlib
import logging
import os
import shutil
import sys
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Import runtime policy before torch/transformers so Inductor cache location is
# fixed before PyTorch can establish its /tmp process default.
from config.runtime import configure_torch_runtime

from tokenizers import Tokenizer
from transformers import Trainer, TrainerCallback, set_seed
import torch
import yaml

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

def _is_rank_zero() -> bool:
    """True only on global rank 0 under torchrun/accelerate DDP."""
    return int(os.environ.get("RANK", "0")) == 0



DATA_DIR    = Path(os.environ.get("DATA_DIR", "data"))
from config.paths import pretrain_dir, resolve_dataset_paths, BASE_RESULTS_DIR
from config.holdout import CONTRACT_NAME, SPLITS, load_contract
from config.checkpoints import resolve_training_checkpoint, validate_or_write_run_audit
from curator.state import atomic_write_json, stable_digest
from pretrain.data.mixture import validate_realized_mixture_report
from pretrain.schedule import resolve_realized_token_schedule, resolve_train_token_limit

RESULTS_DIR = BASE_RESULTS_DIR
PRETRAIN_AUDIT_FILENAME = "pretrain_run_audit.json"
PRETRAIN_AUDIT_VERSION = 2


_NUMERIC_CONFIG_KEYS = {
    "lr", "eps", "weight_decay", "beta1", "beta2",
    "gradient_clip_val", "warmup_ratio",
    "rms_norm_eps", "rope_theta", "initializer_range",
    "dpo_beta", "beta",
}


def _coerce_numeric(node):
    if isinstance(node, dict):
        return {
            k: (float(v) if k in _NUMERIC_CONFIG_KEYS and isinstance(v, str) else _coerce_numeric(v))
            for k, v in node.items()
        }
    if isinstance(node, list):
        return [_coerce_numeric(x) for x in node]
    return node


def load_config(config_path: Path) -> dict:
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    return _coerce_numeric(cfg)



def tokenizer_fingerprint(tokenizer_path: Path) -> str:
    """Return the same tokenizer fingerprint used by tokenization metadata."""
    tok = Tokenizer.from_file(str(tokenizer_path))
    return hashlib.sha256(tok.to_str().encode("utf-8")).hexdigest()


def validate_active_tokenizer_matches_tokenized_data(tokenized_dir: Path, tokenizer_dir: Path) -> None:
    """Fail fast if tokenized train.bin was produced with a different tokenizer."""
    train_meta_path = tokenized_dir / "train.json"
    active_tokenizer_path = tokenizer_dir / "slm_tokenizer.json"

    if not train_meta_path.exists():
        raise FileNotFoundError(f"Missing tokenized metadata: {train_meta_path}")

    if not active_tokenizer_path.exists():
        raise FileNotFoundError(f"Missing active tokenizer: {active_tokenizer_path}")

    with train_meta_path.open("r", encoding="utf-8") as f:
        train_meta = json.load(f)

    expected = train_meta.get("tokenizer_sha256")
    if not expected:
        raise RuntimeError(
            f"{train_meta_path} does not contain tokenizer_sha256; refusing to train."
        )

    actual = tokenizer_fingerprint(active_tokenizer_path)

    if actual != expected:
        raise RuntimeError(
            "Tokenizer/tokenized artifact mismatch.\n"
            f"Tokenized metadata: {train_meta_path}\n"
            f"Expected tokenizer fingerprint: {expected}\n"
            f"Active tokenizer: {active_tokenizer_path}\n"
            f"Actual tokenizer fingerprint:   {actual}\n"
            "Refusing to train. Restore the size-specific tokenizer that produced train.bin."
        )

    for split in ("val", "test"):
        path = tokenized_dir / f"{split}.json"
        metadata = _read_required_json(path, f"{split} tokenized metadata")
        if metadata.get("tokenizer_sha256") != actual:
            raise RuntimeError(f"Tokenizer/{split} artifact mismatch: {path}")
    log.info("Tokenizer fingerprint matches all three tokenized splits: %s", actual)


def validate_tokenizer(tokenizer_dir: Path, tokenized_dir: Path) -> None:
    if not tokenizer_dir.exists() or not any(tokenizer_dir.iterdir()):
        raise RuntimeError(
            f"Tokenizer directory missing or empty: {tokenizer_dir}\n"
            f"Retrain with: make tokenizer SIZE=<size>\n"
            f"Or restore with: make artifacts-download SIZE=<size> "
            f"RUN_ID=<run-id> ARTIFACT_STAGES=tokenizer"
        )

    required_files = {
        "tokenizer_config.json": (
            "Contains the baked-in chat_template required by train_sft.py. "
            "Retrain the tokenizer: make tokenizer"
        ),
        "slm_tokenizer.json": (
            "Raw BPE tokenizer required by tokenize_data.py. "
            "Retrain the tokenizer: make tokenizer"
        ),
    }

    for filename, hint in required_files.items():
        path = tokenizer_dir / filename
        if not path.exists():
            raise RuntimeError(f"Missing tokenizer file: {path}\n{hint}")
        try:
            with open(path) as f:
                json.load(f)
        except json.JSONDecodeError as e:
            raise RuntimeError(
                f"Tokenizer file is not valid JSON: {path}\n"
                f"  Error: {e}\n"
                f"  Hint: {hint}"
            ) from e

    log.info(f"Tokenizer validated at {tokenizer_dir}")
    validate_active_tokenizer_matches_tokenized_data(tokenized_dir, tokenizer_dir)


def resolve_pretrain_checkpoint(output_dir: Path, *, resume,
                                world_size: int | None = None, require_scaler: bool = False) -> Path | None:
    return resolve_training_checkpoint(output_dir, resume=resume,
                                       audit_filename=PRETRAIN_AUDIT_FILENAME,
                                       world_size=world_size, require_scaler=require_scaler)


def validate_model_tokenizer_contract(model_config, tokenizer_dir: Path) -> None:
    """Validate vocabulary and special-token IDs without allocating a model."""
    tokenizer_path = tokenizer_dir / "slm_tokenizer.json"
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    tokenizer_vocab_size = tokenizer.get_vocab_size(with_added_tokens=True)

    if tokenizer_vocab_size != model_config.vocab_size:
        raise RuntimeError(
            f"Model/tokenizer vocabulary mismatch: model config expects "
            f"{model_config.vocab_size:,} tokens but {tokenizer_path} contains "
            f"{tokenizer_vocab_size:,}."
        )

    required_tokens = {
        "pad_token_id": "<PAD>",
        "bos_token_id": "<BOS>",
        "eos_token_id": "<EOS>",
    }
    for name, token in required_tokens.items():
        token_id = getattr(model_config, name)
        if token_id is None or not 0 <= token_id < tokenizer_vocab_size:
            raise RuntimeError(
                f"Model config {name}={token_id!r} is outside tokenizer "
                f"vocabulary size {tokenizer_vocab_size:,}."
            )
        tokenizer_token_id = tokenizer.token_to_id(token)
        if tokenizer_token_id != token_id:
            raise RuntimeError(
                f"Model/tokenizer special-token mismatch: model config "
                f"{name}={token_id}, but tokenizer token {token!r} has ID "
                f"{tokenizer_token_id!r}."
            )


def validate_preflight_gpu(expected_gpus: int, precision: str) -> None:
    """Fail before optimization when the requested GPU contract is unavailable."""
    if expected_gpus < 1:
        raise ValueError(f"expected_gpus must be >= 1, got {expected_gpus}")
    if not torch.cuda.is_available():
        raise RuntimeError(
            f"Pretraining preflight requires CUDA for GPUS={expected_gpus}, "
            "but torch.cuda.is_available() is false."
        )

    visible_gpus = torch.cuda.device_count()
    if visible_gpus < expected_gpus:
        raise RuntimeError(
            f"Pretraining requested {expected_gpus} GPU(s), but only "
            f"{visible_gpus} are visible."
        )
    if precision == "bf16" and not torch.cuda.is_bf16_supported():
        raise RuntimeError("The generated pretraining config requires BF16 support.")

    log.info(
        "GPU preflight passed: requested=%d, visible=%d, precision=%s",
        expected_gpus,
        visible_gpus,
        precision,
    )


def resolve_distributed_strategy(
    requested: str | None,
    world_size: int,
) -> str:
    """Resolve the topology without changing Accelerate's launch behavior."""
    if world_size < 1:
        raise ValueError(f"world_size must be >= 1, got {world_size}")

    strategy = requested or os.environ.get("SLM_DISTRIBUTED_STRATEGY")
    if not strategy:
        if world_size == 1:
            strategy = "single"
        else:
            strategy = "ddp"

    if strategy not in {"single", "ddp"}:
        raise ValueError(
            f"distributed strategy must be single or ddp; got {strategy!r}"
        )
    if strategy == "single" and world_size != 1:
        raise RuntimeError(
            f"single-process topology cannot use world_size={world_size}"
        )
    if strategy == "ddp" and world_size < 2:
        raise RuntimeError(
            f"{strategy} topology requires at least two processes"
        )
    return strategy


def _read_required_json(path: Path, label: str) -> dict:
    if not path.is_file():
        raise FileNotFoundError(f"Missing {label}: {path}")
    try:
        with path.open(encoding="utf-8") as handle:
            value = json.load(handle)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Invalid JSON in {label}: {path}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must contain a JSON object: {path}")
    return value


def tokenized_data_identity(tokenized_dir: Path) -> dict:
    """Return a portable identity for the manifest-complete tokenized corpus."""
    from curator.state import manifest_outputs_match
    if not manifest_outputs_match(tokenized_dir, output_pattern="[tv]*"):
        raise RuntimeError(f"Incomplete or changed tokenized artifacts: {tokenized_dir}")
    completion = _read_required_json(
        tokenized_dir / "_SUCCESS.json",
        "tokenized completion manifest",
    )
    required_manifest_fields = (
        "manifest_version",
        "contract_sha256",
        "input_signature",
        "output_signature",
    )
    missing = [
        field for field in required_manifest_fields
        if completion.get(field) in (None, "")
    ]
    if missing:
        raise RuntimeError(
            f"{tokenized_dir / '_SUCCESS.json'} is missing required fields: "
            f"{missing}"
        )

    splits = {}
    split_metadata = {}
    for split in SPLITS:
        metadata_path = tokenized_dir / f"{split}.json"
        binary_path = tokenized_dir / f"{split}.bin"
        metadata = _read_required_json(
            metadata_path,
            f"tokenized {split} metadata",
        )
        required_metadata_fields = (
            "n_tokens",
            "n_docs",
            "bos_id",
            "eos_id",
            "dtype",
            "format_version",
            "input_sha256",
            "tokenizer_sha256",
            "implementation_sha256",
            "binary_sha256",
            "tokenizer_file_sha256",
            "test_split_sha256",
            "vocab_size",
        )
        missing_metadata = [
            field for field in required_metadata_fields
            if metadata.get(field) in (None, "")
        ]
        if missing_metadata:
            raise RuntimeError(
                f"{metadata_path} is missing required fields: "
                f"{missing_metadata}"
            )
        if not binary_path.is_file():
            raise FileNotFoundError(f"Missing tokenized {split} binary: {binary_path}")
        split_metadata[split] = metadata
        splits[split] = {
            "metadata_sha256": stable_digest(metadata),
            "binary_bytes": binary_path.stat().st_size,
            "n_tokens": metadata["n_tokens"],
            "n_docs": metadata["n_docs"],
            "bos_id": metadata["bos_id"],
            "eos_id": metadata["eos_id"],
            "dtype": metadata["dtype"],
            "format_version": metadata["format_version"],
            "input_sha256": metadata["input_sha256"],
            "tokenizer_sha256": metadata["tokenizer_sha256"],
            "implementation_sha256": metadata["implementation_sha256"],
            "binary_sha256": metadata["binary_sha256"],
            "tokenizer_file_sha256": metadata["tokenizer_file_sha256"],
            "test_split_sha256": metadata["test_split_sha256"],
            "vocab_size": metadata["vocab_size"],
        }
        if metadata["dtype"] != "uint16" or binary_path.stat().st_size != metadata["n_tokens"] * 2:
            raise RuntimeError(f"Binary size/dtype mismatch: {binary_path}")
        from config.holdout import sha256_file
        if sha256_file(binary_path) != metadata["binary_sha256"]:
            raise RuntimeError(f"Binary fingerprint mismatch: {binary_path}")

    holdout = load_contract(tokenized_dir, stage="validated")
    for split, meta in split_metadata.items():
        expected = holdout["contract"]["splits"][split]
        if (meta["test_split_sha256"] != holdout["sha256"]
                or meta["input_sha256"] != expected["sha256"]
                or meta["n_docs"] != expected["documents"]):
            raise RuntimeError(f"Tokenized {split} does not match the holdout contract")
        for field in ("tokenizer_sha256", "bos_id", "eos_id", "vocab_size", "format_version"):
            if meta[field] != split_metadata["train"][field]:
                raise RuntimeError(f"Mixed tokenized artifact set: {split}.{field}")

    if (
        splits["train"]["tokenizer_sha256"]
        != splits["val"]["tokenizer_sha256"]
    ):
        raise RuntimeError(
            "Train, validation and test binaries were created with different tokenizers"
        )

    mixture_path = tokenized_dir / "token_mixture.json"
    mixture = _read_required_json(mixture_path, "realized token mixture report")
    validate_realized_mixture_report(
        mixture,
        split_metadata["train"],
        split_metadata["val"],
        split_metadata["test"],
    )

    return {
        "manifest": {
            field: completion[field]
            for field in required_manifest_fields
        },
        "splits": splits,
        "test_split_sha256": holdout["sha256"],
        "realized_mixture": {
            "report_sha256": stable_digest(mixture),
            "contract_sha256": mixture["contract_sha256"],
            "status": mixture["status"],
        },
    }


def build_pretrain_run_contract(
    *,
    cfg: dict,
    run_size: str,
    tokenizer_dir: Path,
    tokenized_dir: Path,
    world_size: int,
    distributed_strategy: str,
    dataset_size: str | None = None,
    dataset_run_id: str | None = None,
    selected_training_tokens: dict | None = None,
) -> dict:
    """Build the immutable inputs required to resume a pretraining run."""
    return {
        "contract_version": PRETRAIN_AUDIT_VERSION,
        "run_size": run_size,
        "dataset_size": dataset_size or run_size,
        "dataset_run_id": dataset_run_id,
        "selected_training_tokens": selected_training_tokens,
        "resolved_config": cfg,
        "resolved_config_sha256": stable_digest(cfg),
        "tokenizer": {
            "sha256": tokenizer_fingerprint(
                tokenizer_dir / "slm_tokenizer.json"
            ),
        },
        "tokenized_data": tokenized_data_identity(tokenized_dir),
        "distributed": {
            "world_size": world_size,
            "strategy": distributed_strategy,
        },
    }


def validate_or_write_pretrain_audit(
    output_dir: Path, contract: dict, *, resume: bool, write: bool,
) -> Path:
    return validate_or_write_run_audit(
        output_dir, contract, audit_filename=PRETRAIN_AUDIT_FILENAME,
        schema_version=PRETRAIN_AUDIT_VERSION, resume=resume, write=write,
    )


class VRAMProbe(TrainerCallback):
    """Log peak VRAM at step 200 so the analytical profile can be calibrated."""
    def on_step_end(self, args, state, control, **kwargs):
        if state.global_step == 200 and torch.cuda.is_available():
            alloc = torch.cuda.max_memory_allocated() / 1e9
            reserved = torch.cuda.max_memory_reserved() / 1e9
            log.info(f"[VRAMProbe step 200] allocated peak: {alloc:.2f} GB, "
                     f"reserved peak: {reserved:.2f} GB")


def _uses_fused_linear_cross_entropy(model) -> bool:
    return bool(getattr(model, "_fused_linear_ce_enabled", False))


class SLMTrainer(Trainer):
    """
    Trainer subclass for pretraining.

    Handles dict / ModelOutput / tuple return types, including nested
    compiled-output cases like ({'loss': ..., 'logits': ...},).
    """

    @staticmethod
    def _extract_loss(outputs, context: str):
        """
        Extract loss from common model output forms:

        - {"loss": tensor, "logits": tensor}
        - {"loss": {"loss": tensor, "logits": tensor}}
        - ModelOutput with .loss
        - tuple/list where first item is loss
        - tuple/list where first item is dict/ModelOutput containing loss
        """
        if isinstance(outputs, dict):
            loss = outputs.get("loss")
            if isinstance(loss, (dict, tuple, list)):
                return SLMTrainer._extract_loss(loss, context)

        elif hasattr(outputs, "loss"):
            loss = outputs.loss
            if isinstance(loss, (dict, tuple, list)):
                return SLMTrainer._extract_loss(loss, context)

        elif isinstance(outputs, (tuple, list)):
            if len(outputs) == 0:
                raise TypeError(f"Empty output tuple/list during {context}")
            return SLMTrainer._extract_loss(outputs[0], context)

        else:
            raise TypeError(
                f"Unsupported model output type during {context}: {type(outputs)}"
            )

        if loss is None:
            raise TypeError(
                f"Output did not contain loss during {context}. "
                f"Output type: {type(outputs)}"
            )

        if not torch.is_tensor(loss):
            raise TypeError(
                f"Expected {context} loss to be a torch.Tensor, got {type(loss)}"
            )

        return loss

    def compute_loss(
        self,
        model,
        inputs,
        return_outputs=False,
        num_items_in_batch=None,
    ):
        model_inputs = dict(inputs)
        if _uses_fused_linear_cross_entropy(model) and not return_outputs:
            model_inputs["materialize_logits"] = False
        outputs = model(
            **model_inputs,
            num_items_in_batch=num_items_in_batch,
        )
        loss = self._extract_loss(outputs, context="training")
        return (loss, outputs) if return_outputs else loss

    def prediction_step(
        self,
        model,
        inputs,
        prediction_loss_only,
        ignore_keys=None,
    ):
        """
        Evaluation step for causal LM pretraining.

        Always returns loss only. Logits are intentionally dropped because:
        1. Pretraining eval only needs loss/perplexity tracking.
        2. Logits are [B, T, vocab]. At B=64, T=2048, vocab=32000,
           that is enormous and can cause eval OOMs.

        If logits are needed later for compute_metrics, do not return full
        logits from this method. Instead compute the metric in chunks, move
        reduced values to CPU, or compute the metric inside the model/trainer
        and log only scalar summaries.
        """
        inputs = self._prepare_inputs(inputs)

        if _uses_fused_linear_cross_entropy(model):
            inputs = dict(inputs)
            inputs["materialize_logits"] = False

        with torch.no_grad():
            outputs = model(**inputs)

        loss = self._extract_loss(outputs, context="eval")
        return (loss.detach().mean(), None, None)
    

def build_training_args(cfg: dict, output_dir: Path, resume: bool):
    from transformers import TrainingArguments

    train_cfg = cfg["training"]
    optim_cfg = cfg["optimizer"]

    has_cuda = torch.cuda.is_available()
    precision = train_cfg.get("precision", "bf16")
    use_bf16  = has_cuda and precision == "bf16"
    use_fp16  = has_cuda and precision == "fp16"

    # Autotune the fixed-shape decoder without enabling CUDA Graphs. Measure
    # startup separately from steady updates; a faster kernel is not guaranteed.
    # The accepted Liger loss retains its existing compiler boundary.
    # Set torch_compile_mode: default for comparison, or torch_compile: false
    # when debugging the model.
    torch_compile = bool(train_cfg.get("torch_compile", True)) and has_cuda

    return TrainingArguments(
        output_dir=str(output_dir),
        max_steps=train_cfg["max_steps"],
        warmup_steps=train_cfg.get("warmup_steps", 2000),
        per_device_train_batch_size=train_cfg["micro_batch_size"],
        per_device_eval_batch_size=train_cfg.get("eval_micro_batch_size", train_cfg["micro_batch_size"]),
        gradient_accumulation_steps=train_cfg.get("gradient_accumulation_steps", 1),

        learning_rate=float(optim_cfg["lr"]),
        weight_decay=float(optim_cfg.get("weight_decay", 0.1)),
        adam_beta1=float(optim_cfg.get("beta1", 0.9)),
        adam_beta2=float(optim_cfg.get("beta2", 0.95)),
        adam_epsilon=float(optim_cfg.get("eps", 1e-8)),
        max_grad_norm=float(train_cfg.get("gradient_clip_val", 1.0)),
        optim="adamw_torch_fused" if has_cuda else "adamw_torch",

        lr_scheduler_type=train_cfg.get("lr_scheduler", "cosine"),
        bf16=use_bf16,
        fp16=use_fp16,
        tf32=has_cuda,

        torch_compile=torch_compile,
        torch_compile_backend=train_cfg.get("torch_compile_backend", "inductor"),
        torch_compile_mode=train_cfg.get("torch_compile_mode", "max-autotune-no-cudagraphs"),

        eval_strategy="steps",
        eval_steps=train_cfg.get("eval_steps", 1000),
        save_strategy="steps",
        save_steps=train_cfg.get("save_steps", 1000),
        save_total_limit=train_cfg.get("save_total_limit", 3),
        load_best_model_at_end=False,

        logging_strategy="steps",
        logging_steps=train_cfg.get("log_steps", 10),
        report_to=train_cfg.get("report_to", ["wandb"]),
        run_name=cfg.get("name", "slm-pretrain"),

        dataloader_num_workers=train_cfg.get("num_workers", 4),
        dataloader_pin_memory=has_cuda,
        remove_unused_columns=False,
        include_num_input_tokens_seen="all",
        seed=train_cfg.get("seed", 42),

        gradient_checkpointing=train_cfg.get("gradient_checkpointing", False),
        ddp_find_unused_parameters=False,
    )


def resolve_dataset_run_id(paths: dict, expected: str | None = None, *, required: bool = False) -> str | None:
    """Bind an explicitly requested source RUN_ID to restored metadata."""
    import re
    records = []
    run_path = paths["run_id"]
    if run_path.is_file():
        raw = run_path.read_text().strip()
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"run_id": raw}
        if isinstance(payload, str):
            payload = {"run_id": payload}
        if not isinstance(payload, dict):
            raise RuntimeError(f"Invalid dataset RUN_ID record: {run_path}")
        records.append(payload)
    pipeline_path = paths["metadata"] / "pipeline_manifest.json"
    if pipeline_path.is_file():
        pipeline = _read_required_json(pipeline_path, "dataset pipeline manifest")
        records.append(pipeline)
        from config.holdout import sha256_file
        required_files = [f"tokenized/{split}.json" for split in SPLITS] + [
            "tokenized/_SUCCESS.json", "tokenized/test_contract.json", "tokenizer/slm_tokenizer.json"]
        for name in required_files:
            expected_sha = pipeline.get("file_sha256", {}).get(name)
            path = paths["root"] / name
            if not expected_sha or not path.is_file() or sha256_file(path) != expected_sha:
                raise RuntimeError(f"Consumed dataset metadata fingerprint mismatch: {name}")
    elif required or expected:
        raise RuntimeError("Explicit/cross-size dataset consumption requires pipeline metadata; run artifacts-index or restore the matched bundle")
    ids = {row.get("run_id") for row in records if row.get("run_id")}
    if expected:
        ids.add(expected)
    if len(ids) > 1:
        raise RuntimeError("Requested/active dataset RUN_ID mismatch; restore the complete source artifact set")
    if (required or expected) and not records:
        raise RuntimeError("Cross-size/explicit RUN_ID consumption requires restored dataset provenance")
    for row in records:
        if row.get("size", paths["dataset_size"]) != paths["dataset_size"]:
            raise RuntimeError("Dataset provenance SIZE does not match DATASET_SIZE")
    run_id = next(iter(ids), None)
    if run_id is not None and not re.fullmatch(re.escape(paths["dataset_size"]) + r"-\d{8}-[A-Za-z0-9._-]+", run_id):
        raise RuntimeError(f"Invalid source dataset RUN_ID: {run_id!r}")
    if required and run_id is None:
        raise RuntimeError("Cross-size training requires a source dataset RUN_ID")
    return run_id


def _size_from_model_name(model_name: str) -> str:
    name = model_name.removeprefix("slm-")
    return name.split("-")[0]


def main():
    parser = argparse.ArgumentParser(description="SLM Pretraining")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--resume", nargs="?", const="latest", default=None,
                        help="Resume latest complete checkpoint, or select a same-run checkpoint path")
    parser.add_argument(
        "--preflight-only",
        action="store_true",
        help="Validate run inputs, GPU visibility, and resume state without optimization",
    )
    parser.add_argument(
        "--expected-gpus",
        type=int,
        default=None,
        help="Required visible GPU count for --preflight-only",
    )
    parser.add_argument(
        "--distributed-strategy",
        choices=["single", "ddp"],
        default=None,
        help="Optional topology identity; otherwise inferred from the launched world",
    )
    parser.add_argument("--dataset-size", default=os.environ.get("DATASET_SIZE"))
    parser.add_argument("--dataset-run-id", default=os.environ.get("DATASET_RUN_ID"))
    parser.add_argument("--data-dir", type=Path, default=DATA_DIR)
    parser.add_argument("--results-dir", type=Path, default=RESULTS_DIR)
    args = parser.parse_args()

    cfg        = load_config(args.config)
    model_name = cfg["name"]
    run_size = (
        cfg.get("size")
        or cfg.get("data", {}).get("size")
        or model_name.removeprefix("slm-")
    )
    dataset_size = args.dataset_size or cfg.get("data", {}).get("dataset_size") or run_size
    artifact_paths = resolve_dataset_paths(run_size, dataset_size, data_root=args.data_dir)
    resolved_tokenized_dir = artifact_paths["tokenized"]
    dataset_run_id = resolve_dataset_run_id(artifact_paths, args.dataset_run_id,
                                          required=dataset_size != run_size)
    if cfg.get("output_dir"):
        output_dir = Path(cfg["output_dir"])
        if not output_dir.is_absolute():
            output_dir = args.results_dir.parent / output_dir
    else:
        output_dir = args.results_dir / "runs" / _size_from_model_name(model_name) / "pretrain"

    log.info(f"=== SLM Pretraining ===")
    log.info(f"Config:     {args.config}")
    log.info(f"Model:      {model_name}")
    log.info(f"Output:     {output_dir}")
    log.info(f"Device:     {'cuda' if torch.cuda.is_available() else 'cpu'}")
    configure_torch_runtime(log)
    if torch.cuda.is_available():
        log.info(f"GPU:        {torch.cuda.get_device_name(0)} "
                 f"({torch.cuda.get_device_properties(0).total_memory / 1e9:.0f} GB)")

    resume_checkpoint = resolve_pretrain_checkpoint(
        output_dir,
        resume=args.resume,
        world_size=(args.expected_gpus if args.preflight_only and args.expected_gpus is not None
                    else int(os.environ.get("WORLD_SIZE", "1"))),
        require_scaler=bool(torch.cuda.is_available() and cfg["training"].get("precision") == "fp16"),
    )
    if resume_checkpoint is not None:
        log.info(f"Resuming from checkpoint: {resume_checkpoint}")

    tokenizer_dir = artifact_paths["tokenizer"]
    log.info("Dataset: SIZE=%s DATASET_SIZE=%s RUN_ID=%s", run_size, dataset_size, dataset_run_id)
    validate_tokenizer(tokenizer_dir, resolved_tokenized_dir)

    from model import SLMConfig, SLMForCausalLM

    model_cfg_dict = cfg["model"]
    model_config = SLMConfig(
        vocab_size=model_cfg_dict["vocab_size"],
        hidden_size=model_cfg_dict["hidden_size"],
        intermediate_size=model_cfg_dict.get("intermediate_size"),
        num_hidden_layers=model_cfg_dict["num_hidden_layers"],
        num_attention_heads=model_cfg_dict["num_attention_heads"],
        num_key_value_heads=model_cfg_dict["num_key_value_heads"],
        max_position_embeddings=model_cfg_dict["max_position_embeddings"],
        rope_theta=model_cfg_dict.get("rope_theta", 10000.0),
        rms_norm_eps=model_cfg_dict.get("rms_norm_eps", 1e-5),
        initializer_range=model_cfg_dict.get("initializer_range", 0.02),
        tie_word_embeddings=model_cfg_dict.get("tie_word_embeddings", True),
        attn_implementation=cfg["training"].get("attn_implementation", "flash_attention_3"),
    )
    validate_model_tokenizer_contract(model_config, tokenizer_dir)

    from pretrain.data.dataset import load_train_val

    seq_len = model_cfg_dict["max_position_embeddings"]

    log.info(f"Loading datasets from {resolved_tokenized_dir}")
    train_token_limit = resolve_train_token_limit(cfg, run_size=run_size, dataset_size=dataset_size)
    train_ds, val_ds = load_train_val(tokenized_dir=resolved_tokenized_dir, seq_len=seq_len,
                                    max_train_tokens=train_token_limit)
    if run_size == "mini" and train_ds.token_budget()["selected_unique_tokens"] < 1_400_000_000:
        raise RuntimeError("Mini requires at least 1.4B usable unique training tokens after budget selection")

    log.info(f"Train examples: {len(train_ds):,}")
    log.info(f"Val examples:   {len(val_ds):,}")

    budget = train_ds.token_budget()
    log.info(f"Training tokens: {budget['total_training_tokens'] / 1e9:.2f}B")

    world_size = (
        args.expected_gpus
        if args.preflight_only and args.expected_gpus is not None
        else int(os.environ.get("WORLD_SIZE", "1"))
    )
    cfg, realized_schedule = resolve_realized_token_schedule(
        cfg,
        run_size=run_size,
        realized_train_tokens=budget["n_tokens"],
        seq_len=seq_len,
        world_size=world_size,
    )
    training_args = build_training_args(cfg, output_dir, resume=args.resume)
    distributed_strategy = resolve_distributed_strategy(
        args.distributed_strategy,
        world_size,
    )
    global_batch = (
        training_args.per_device_train_batch_size
        * training_args.gradient_accumulation_steps
        * world_size
    )
    tokens_per_step = global_batch * seq_len
    scheduled_tokens = tokens_per_step * training_args.max_steps

    if realized_schedule is not None:
        log.info(
            "Resolved schedule from tokenized train corpus: usable_tokens=%s, "
            "epochs=%d, rounding_excess_tokens=%s",
            f'{realized_schedule["usable_train_tokens_per_epoch"]:,}',
            realized_schedule["epochs"],
            f'{realized_schedule["rounding_excess_tokens"]:,}',
        )

    log.info(
        "Training plan: strategy=%s, processes=%d, global_batch=%d sequences, "
        "tokens_per_step=%s, max_steps=%s, scheduled_tokens=%.2fB",
        distributed_strategy,
        world_size,
        global_batch,
        f"{tokens_per_step:,}",
        f"{training_args.max_steps:,}",
        scheduled_tokens / 1e9,
    )

    run_contract = build_pretrain_run_contract(
        cfg=cfg,
        run_size=run_size,
        tokenizer_dir=tokenizer_dir,
        tokenized_dir=resolved_tokenized_dir,
        world_size=world_size,
        distributed_strategy=distributed_strategy,
        dataset_size=dataset_size,
        dataset_run_id=dataset_run_id,
        selected_training_tokens=budget,
    )

    # Capture verified measured metadata now, rather than reading a mutable
    # DATA_DIR later during model-card generation on another host.
    measured_mixture = json.loads((resolved_tokenized_dir / "token_mixture.json").read_text(encoding="utf-8"))
    if stable_digest(measured_mixture) != run_contract["tokenized_data"]["realized_mixture"]["report_sha256"]:
        raise RuntimeError("Token mixture changed after preflight identity verification")
    # Record whether counting covered the *whole* run. Legacy resumptions may
    # acquire a nonzero counter after this upgrade; that is still only a suffix,
    # even on a second resume, and must not be reported as full-run consumption.
    previous_contract = {}
    audit_path = output_dir / PRETRAIN_AUDIT_FILENAME
    if audit_path.is_file():
        previous_contract = json.loads(audit_path.read_text(encoding="utf-8")).get("contract", {})
    complete_token_counter = (not audit_path.exists() and resume_checkpoint is None) or (
        previous_contract.get("input_token_counting") == "all-from-start")
    if complete_token_counter:
        run_contract["input_token_counting"] = "all-from-start"
        if resume_checkpoint is not None:
            prior_state = json.loads((resume_checkpoint / "trainer_state.json").read_text(encoding="utf-8"))
            if prior_state.get("global_step", 0) > 0 and prior_state.get("num_input_tokens_seen", 0) <= 0:
                raise RuntimeError("Checkpoint is missing the input-token counter required by its run audit")

    if args.preflight_only:
        validate_or_write_pretrain_audit(
            output_dir,
            run_contract,
            resume=args.resume,
            write=False,
        )
        validate_preflight_gpu(
            world_size,
            str(cfg["training"].get("precision", "bf16")),
        )
        log.info("Pretraining preflight passed; no model weights were allocated.")
        return

    if _is_rank_zero():
        validate_or_write_pretrain_audit(
            output_dir,
            run_contract,
            resume=args.resume,
            write=True,
        )

    # Trainer seeds after construction; apply the recorded seed before weights
    # are drawn. On resume Trainer still restores the saved weights/RNG state.
    set_seed(training_args.seed)
    log.info("Initializing model%s...", " for resume" if args.resume else " from scratch")
    model = SLMForCausalLM(model_config)
    if torch.cuda.is_available() and cfg["training"].get("fused_linear_cross_entropy", True):
        model.enable_fused_linear_cross_entropy()
        log.info("Fused linear cross-entropy enabled for loss-only pretraining/evaluation")
    n_params = sum(p.numel() for p in model.parameters())
    log.info(f"Parameters: {n_params:,} ({n_params / 1e6:.1f}M)")

    log.info(
        f"Throughput knobs: "
        f"micro_batch={training_args.per_device_train_batch_size}, "
        f"grad_accum={training_args.gradient_accumulation_steps}, "
        f"bf16={training_args.bf16}, "
        f"optim={training_args.optim}, "
        f"compile={training_args.torch_compile}, "
        f"compile_mode={training_args.torch_compile_mode}, "
        f"attention={model.config._attn_implementation}, "
        f"grad_ckpt={training_args.gradient_checkpointing}"
    )

    if "wandb" in training_args.report_to and _is_rank_zero():
        import wandb
        wandb.init(
            project=cfg.get("wandb_project", "slm"),
            name=model_name,
            config={
                "model":           model_cfg_dict,
                "training":        cfg["training"],
                "optimizer":       cfg["optimizer"],
                "n_params":        n_params,
                "n_train_tokens":  budget["total_training_tokens"],
                "n_val_examples":  len(val_ds),
            },
        )

    from pretrain.diagnostics import make_probe_callback
    probe_cfg = cfg.get("generation_probes", {})
    callbacks = [VRAMProbe()]
    if probe_cfg.get("enabled", True):
        callbacks.append(make_probe_callback(tokenizer_dir, output_dir, probe_cfg))
    trainer = SLMTrainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        callbacks=callbacks,
    )

    run_baseline_eval = cfg.get(
        "run_baseline_eval",
        cfg.get("training", {}).get("run_baseline_eval", True),
    )
    if not args.resume and run_baseline_eval:
        log.info("Running baseline eval before training (step 0)...")
        baseline = trainer.evaluate()
        log.info(f"Baseline eval: {baseline}")
    elif not args.resume:
        log.info("Skipping baseline eval before training (run_baseline_eval=false)")

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    log.info("Starting training...")
    train_result = trainer.train(resume_from_checkpoint=resume_checkpoint if args.resume else None)
    trainer.save_metrics("train", train_result.metrics)
    trainer.save_state()
    final_dir = output_dir / "final"
    if _is_rank_zero():
        log.info("Saving final model...")
        trainer.save_model(str(final_dir))
        model_config.save_pretrained(str(final_dir))

        shutil.copytree(tokenizer_dir, final_dir / "tokenizer", dirs_exist_ok=True)
        log.info(f"Tokenizer copied to {final_dir / 'tokenizer'}")
        shutil.copy2(
            output_dir / PRETRAIN_AUDIT_FILENAME,
            final_dir / PRETRAIN_AUDIT_FILENAME,
        )
        log.info(
            "Pretraining run audit copied to %s",
            final_dir / PRETRAIN_AUDIT_FILENAME,
        )

        from config.provenance import save_training_provenance
        save_training_provenance(
            final_dir, token_mixture=measured_mixture,
            training_metrics={
                "global_step": trainer.state.global_step,
                "consumed_input_tokens": trainer.state.num_input_tokens_seen if complete_token_counter else None,
                "token_counter_complete": complete_token_counter,
                "scheduled_input_tokens": scheduled_tokens,
            },
        )
        log.info(f"Model saved to {final_dir}")

    if torch.distributed.is_available() and torch.distributed.is_initialized():
        torch.distributed.barrier()

    # Optimization and checkpoint selection have ended. Test is opened only here.
    from pretrain.diagnostics import final_loss_metrics
    final_metrics = final_loss_metrics(trainer, resolved_tokenized_dir, seq_len)
    if _is_rank_zero():
        from pretrain.diagnostics import final_cases, generate_rows, generic_cases, probe_settings
        from transformers import AutoTokenizer
        try:
            hf_tokenizer = AutoTokenizer.from_pretrained(str(tokenizer_dir), local_files_only=True)
            cases = final_cases(artifact_paths["validated"], resolved_tokenized_dir, hf_tokenizer,
                                prefix_count=int(cfg.get("final_evaluation", {}).get("prefix_count", 5)))
            rows = generate_rows(trainer.accelerator.unwrap_model(trainer.model), hf_tokenizer,
                                 cases + generic_cases(), step=trainer.state.global_step,
                                 settings=probe_settings(probe_cfg))
            diagnostic_error = None
        except Exception as exc:
            log.exception("Final qualitative generation failed; preserving loss metrics and checkpoint")
            rows, diagnostic_error = [], str(exc)
        atomic_write_json(output_dir / "final_pretraining_eval.json", {
            "training_contract_sha256": stable_digest(run_contract),
            "training_metrics": train_result.metrics, "metrics": final_metrics,
            "selected_training_tokens": budget, "parameters": n_params,
            "unique_training_tokens_per_parameter": budget["selected_unique_tokens"] / n_params,
            "corpus_supported_qa_status": "not_provided", "qualitative_results": rows,
            "qualitative_error": diagnostic_error})

    if _is_rank_zero():
        shutil.copy2(output_dir / "final_pretraining_eval.json", final_dir / "final_pretraining_eval.json")

    if torch.distributed.is_available() and torch.distributed.is_initialized():
        torch.distributed.barrier()
        torch.distributed.destroy_process_group()

    if _is_rank_zero():
        log.info("Pretraining complete.")
        log.info("Next step: make sft")


if __name__ == "__main__":
    main()
