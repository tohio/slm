# Infrastructure

Bootstrap the existing Ubuntu curation/training host roles and verify their
separate dependency stacks. Setup installs system packages, updates `.env` and
shell configuration, and requires appropriate privileges; inspect scripts before
running on an existing multi-purpose host.

## Contents

| File | Purpose |
|---|---|
| `setup_curate.sh` | Curation bootstrap, KenLM build, spaCy/FastText/KenLM assets, paths, and verification |
| `setup_train.sh` | GPU bootstrap, training stack, optional source-run restoration |
| `setup_environment.sh` | Internal pip/uv/conda installer shared by both roles |
| `verify_environment.py` | Pinned role versions and optional CUDA checks |
| `gpu_smoke.py` | Dataset-free eager/compiled training and generation acceptance |

## Setup by role

Prepare `.env` from `.env.sample`, selecting the data/results/export paths and
credentials required by the chosen workflow. W&B is required: populate
`WANDB_API_KEY` and `WANDB_PROJECT`, along with `HF_TOKEN` and the common paths.
Storage settings are validated when selected transfers execute; `HF_USERNAME`
is needed only for model publication. Use separate checkouts/environments
for the two host roles; curation and training require different Transformers/Hub
versions.

```bash
make setup-curate DATA_DIR=/data/slm/data
make setup-train DATA_DIR=/data/slm/data
```

`setup-curate` installs `requirements-curation.txt`, including KenLM build and
orjson/FastText handling; `setup-train` installs the complete GPU and evaluation
stack from `requirements-training.txt`, then builds the FA3 source pinned in
`requirements-flash-attention.txt` against the installed PyTorch. Both include
the common `requirements.txt`. Setup handles the FA3 installation order;
installing `requirements-training.txt` alone does not install FA3.

The training host also needs the **CUDA 13.0 development toolkit**, including
`nvcc` and headers, matching `torch==2.13.0+cu130`. The driver and PyTorch runtime
alone do not provide a compiler. Use a CUDA 13.0 development image or install
that toolkit version using [NVIDIA's Linux installation guide](https://docs.nvidia.com/cuda/cuda-installation-guide-linux/index.html).
If it is not found automatically, set `CUDA_HOME` to its installation directory
before setup, for example:

```bash
export CUDA_HOME=/usr/local/cuda-13.0
make setup-train DATA_DIR=/data/slm/data
```

FA3 is built from Dao-AILab's `hopper` subdirectory at the recorded commit,
with Ampere kernels and backward enabled. Build isolation and dependency
resolution are disabled for this extension so the validated PyTorch stack is
retained. The first build can take substantial time; `MAX_JOBS` controls build
parallelism (default 4). Setup checks the import; `make test-gpu-gate` exercises
the existing eager/compiled training and generation checks when explicitly run.
The A100 speedup and numerical behavior have not been measured for this patch.

### Installer selection

Both commands accept `INSTALLER=pip|uv|conda`; pip/venv is the default. Install
uv or conda first when selecting it. All three place the environment in the
checkout's `.venv`, so existing pipeline commands use the same Python path.
Conda creates a Python 3.12 prefix and installs the role requirements with pip;
it does not select a separate conda CUDA build. uv uses the same pinned CUDA
wheel/index as pip.

```bash
make setup-curate INSTALLER=uv DATA_DIR=/data/slm/data
make setup-train INSTALLER=conda DATA_DIR=/data/slm/data
```

These illustrate alternative hosts, not two roles to layer into one `.venv`.
Make recipes address the repository environment directly. For interactive Python
or pip commands, activate pip/uv with `source .venv/bin/activate`; for conda use
`conda activate "$PWD/.venv"`. Switching between conda and venv requires moving
an existing environment aside explicitly; setup does not silently delete it.

## Curation assets

Setup installs Python dependencies, `wget` for asset downloads, and KenLM Python
bindings from pinned revision `4cb443e60b7bf2c0ddf3c745378f76cb59e254e5`.
Setup invokes the existing internal download helpers to prepare FastText
`lid.176.ftz` and the matched CCNet `en.arpa.bin` / `en.sp.model` pair, then
checks that all three assets load. Expect the KenLM assets to require several GB
of network transfer and storage on a new host. Valid assets are reused; the
CCNet pair is checksum-verified and FastText is validated before promotion from
its partial file. Failed transfers or invalid assets fail setup.

No follow-up download targets are required in the normal workflow. The
`download-fasttext-model` and `download-kenlm-model` helpers remain available for
explicit repair, not as additional setup steps. Curation rechecks prerequisites
at runtime. Dataset access terms and required credentials remain the operator's
responsibility.

## Training and optional restoration

Training setup requires an already working NVIDIA driver (`nvidia-smi`), then
checks the NVIDIA/CUDA/BF16 contract and installs the pinned GPU stack. It does
not install a driver or provide a CPU-only training installation. Model tests
can execute on CPU after this environment has been installed. With no source
run selected it performs setup only. With a source run selected it restores
the requested artifacts; missing credentials fail the transfer rather than
silently skipping it:

```bash
make setup-train SIZE=mini DATASET_SIZE=350m DATASET_RUN_ID=350m-YYYYMMDD-abcdef \
  DATA_DIR=/data/slm/data ARTIFACT_BACKEND=hf
```

Setup never recursively changes ownership of `DATA_DIR`'s parent or an existing
directory tree. It may create a missing project data/cache/results leaf with
privileges and assign that leaf to the invoking user. An existing unwritable
project path fails with an instruction to grant access to that specific path.

The setup restore default is `tokenized,tokenizer,metadata`. Select additional
stages explicitly, for example `ARTIFACT_STAGES=validated,tokenized,tokenizer,metadata`
for final test-document completions. The source tokenizer stays under
`runs/<dataset-size>/tokenizer`; model outputs remain under the model size.

The pinned stack requires CUDA runtime 13.0, driver 580.65.06 or newer, native
GPU architecture support in the installed PyTorch wheel, and BF16 support.
Internal training checks run again at relevant entry points. For diagnosis:

```bash
.venv/bin/python infra/verify_environment.py --profile training --require-cuda
make test-gpu-gate
```

The GPU gate uses a tiny model, not a production corpus or checkpoint. Passing it
is not proof of model convergence or production throughput.

`train-all` already invokes this setup/restore flow. Use it directly for a new
end-to-end training run, or use setup followed by individual stages—not both.

## Configure before launching

```bash
make config-gen SIZE=mini GPUS=1
```

For multiple GPUs substitute the chosen count in `GPUS=N`. Configuration includes
the required DDP launch file; no interactive/global Accelerate setup is needed.
See [config generation](../config_gen/README.md), [artifact routing](../docs/PRETRAINING_DATA.md),
and [training](../docs/TRAIN.md). Serving retains its separate vLLM runtime contract.
