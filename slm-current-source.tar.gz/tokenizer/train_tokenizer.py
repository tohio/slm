"""
tokenizer/train_tokenizer.py
-----------------------------
Train a BPE tokenizer using HuggingFace tokenizers library.

Trains on the validated dataset to ensure the tokenizer vocabulary
reflects the actual cleaned data distribution. A domain-specific
tokenizer encodes the training text more efficiently than a generic
tokenizer (e.g. GPT-2's), reducing the number of tokens per document
and improving training efficiency.

Special tokens are baked in at training time — they cannot be added
later without retraining the tokenizer and resizing model embeddings.

Special tokens:
    Structural:   <PAD>, <UNK>, <BOS>, <EOS>
    Chat:         <|system|>, <|user|>, <|assistant|>, <|endofturn|>
    Code:         <|code|>, <|endofcode|>
    Tool use:     <|tool|>, <|endoftool|>
    Reasoning:    <|reasoning|>, <|endofreasoning|>
    RAG context:  <|context|>, <|endofcontext|>

Vocab size: 32,000 (sufficient for English + code at 125M–1B scale)

Token ID source of truth:
    This module exports both the string list SPECIAL_TOKENS and integer
    constants (PAD_ID, BOS_ID, ...). These are authoritative at training
    time — the trainer guarantees they land at the IDs asserted below.

    Runtime code (inference/utils.py) does NOT import these constants.
    Instead it resolves IDs via tokenizer.convert_tokens_to_ids(...) on
    the loaded tokenizer, so that a re-trained tokenizer with a different
    special-token layout cannot silently mis-map IDs at inference time.
    Tests and training scripts that pre-assert the layout can use these
    constants directly.

BOS/EOS handling:
    BOS and EOS are NOT added automatically by the tokenizer post-processor.
    They must be added explicitly by the training data pipeline where needed.
    Automatic injection via TemplateProcessing corrupts chat-formatted data
    by inserting tokens at positions the model does not expect.

Chat template:
    The Jinja2 chat template is baked into the HuggingFace tokenizer at
    save time so tokenizer.apply_chat_template() works correctly in SFT,
    DPO, and inference — matching the special token structure exactly.

    The template includes {% generation %} and {% endgeneration %} tags
    around assistant responses, required by trl's assistant_only_loss=True
    for answer-only loss masking in SFTTrainer.

Output:
    data/runs/<size>/tokenizer/slm_tokenizer.json
    data/runs/<size>/tokenizer/vocab.json
    data/runs/<size>/tokenizer/merges.txt
    data/runs/<size>/tokenizer/special_tokens.json
    data/runs/<size>/tokenizer/tokenizer.json
    data/runs/<size>/tokenizer/tokenizer_config.json

Usage:
    python tokenizer/train_tokenizer.py
    python tokenizer/train_tokenizer.py --vocab-size 32000
    python tokenizer/train_tokenizer.py --input data/runs/<size>/validated/train.jsonl
"""

import argparse
import json
import logging
import os
import shutil
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config.paths import validated_dir, tokenizer_dir, BASE_DATA_DIR
from curator.state import (
    code_fingerprint,
    file_snapshot,
    manifest_matches,
    manifest_outputs_match,
    stable_digest,
    write_manifest,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

DATA_DIR = BASE_DATA_DIR

# ── Special tokens ─────────────────────────────────────────────────────────────

# The four structural tokens MUST come first and MUST be in this order —
# PAD_ID, UNK_ID, BOS_ID, EOS_ID are referenced by integer ID throughout
# the training pipeline.
STRUCTURAL_TOKENS = [
    "<PAD>",            # 0
    "<UNK>",            # 1
    "<BOS>",            # 2
    "<EOS>",            # 3
]

# Additional special tokens registered with the HuggingFace tokenizer via
# `additional_special_tokens`. Order here determines IDs 4..15 but none of
# these IDs are hard-referenced by integer in training code — runtime
# lookup is done by string via convert_tokens_to_ids().
ADDITIONAL_SPECIAL_TOKENS = [
    # Chat
    "<|system|>",       # 4
    "<|user|>",         # 5
    "<|assistant|>",    # 6
    "<|endofturn|>",    # 7
    # Code
    "<|code|>",         # 8
    "<|endofcode|>",    # 9
    # Tool use
    "<|tool|>",         # 10
    "<|endoftool|>",    # 11
    # Reasoning
    "<|reasoning|>",    # 12
    "<|endofreasoning|>", # 13
    # RAG context
    "<|context|>",      # 14
    "<|endofcontext|>", # 15
]

SPECIAL_TOKENS = STRUCTURAL_TOKENS + ADDITIONAL_SPECIAL_TOKENS

# Token ID constants for use in training scripts. These are authoritative
# only when the tokenizer was trained by this script with this ordering —
# runtime code should resolve IDs via tokenizer.convert_tokens_to_ids().
PAD_ID = 0
UNK_ID = 1
BOS_ID = 2
EOS_ID = 3
SYSTEM_ID = 4
USER_ID = 5
ASSISTANT_ID = 6
ENDOFTURN_ID = 7
CODE_ID = 8
ENDOFCODE_ID = 9
TOOL_ID = 10
ENDOFTOOL_ID = 11
REASONING_ID = 12
ENDOFREASONING_ID = 13
CONTEXT_ID = 14
ENDOFCONTEXT_ID = 15

# Internal consistency check — makes sure nobody renumbers the constants
# without also reordering SPECIAL_TOKENS.
_ID_TO_TOKEN = {
    PAD_ID: "<PAD>", UNK_ID: "<UNK>", BOS_ID: "<BOS>", EOS_ID: "<EOS>",
    SYSTEM_ID: "<|system|>", USER_ID: "<|user|>", ASSISTANT_ID: "<|assistant|>",
    ENDOFTURN_ID: "<|endofturn|>", CODE_ID: "<|code|>", ENDOFCODE_ID: "<|endofcode|>",
    TOOL_ID: "<|tool|>", ENDOFTOOL_ID: "<|endoftool|>",
    REASONING_ID: "<|reasoning|>", ENDOFREASONING_ID: "<|endofreasoning|>",
    CONTEXT_ID: "<|context|>", ENDOFCONTEXT_ID: "<|endofcontext|>",
}
for _i, _tok in enumerate(SPECIAL_TOKENS):
    assert _ID_TO_TOKEN[_i] == _tok, (
        f"SPECIAL_TOKENS[{_i}]={_tok!r} does not match ID constant "
        f"mapping {_i} -> {_ID_TO_TOKEN[_i]!r}. Update both together."
    )

# ── Chat template ──────────────────────────────────────────────────────────────
# Jinja2 template baked into the HuggingFace tokenizer so that
# tokenizer.apply_chat_template() produces the correct format in SFT,
# DPO, and inference.
#
# Format:
#   <BOS><|system|>{content}<|endofturn|>
#   <|user|>{content}<|endofturn|>
#   <|assistant|>{content}<EOS><|endofturn|>
#   <|assistant|>   ← generation prompt (add_generation_prompt=True)
#
# BOS is prepended once at the start of the full sequence.
# EOS is appended at the end of each assistant turn.
# No BOS/EOS on system or user turns — the role tokens are the delimiters.
#
# {% generation %} / {% endgeneration %} tags wrap the assistant response
# content. These are required by trl's assistant_only_loss=True for
# answer-only loss masking in SFTTrainer — trl uses them to identify
# which tokens to compute loss on.

from config.chat import CHAT_TEMPLATE



# ── Text iterator ──────────────────────────────────────────────────────────────

def text_iterator(input_path: Path, batch_size: int = 1000):
    """
    Yield batches of text strings from a JSONL file.

    The HuggingFace tokenizers trainer expects an iterator of
    strings or lists of strings. We yield batches for efficiency.

    Args:
        input_path: Path to JSONL file with "text" field.
        batch_size: Number of texts per batch.
    """
    batch = []
    with open(input_path, encoding="utf-8") as f:
        for line in f:
            record = json.loads(line)
            text = record.get("text", "").strip()
            if text:
                batch.append(text)
            if len(batch) >= batch_size:
                yield batch
                batch = []
    if batch:
        yield batch


# ── Train ──────────────────────────────────────────────────────────────────────

def train_tokenizer(
    input_path: Path,
    output_dir: Path,
    vocab_size: int = 32_000,
    min_frequency: int = 2,
) -> None:
    """
    Train a BPE tokenizer on the validated dataset.

    Args:
        input_path: Path to validated JSONL file.
        output_dir: Directory to save tokenizer files.
        vocab_size: Target vocabulary size. Default: 32,000.
        min_frequency: Minimum token frequency to include in vocab.
    """
    from tokenizers import Tokenizer
    from tokenizers.models import BPE
    from tokenizers.trainers import BpeTrainer
    from tokenizers.pre_tokenizers import ByteLevel
    from tokenizers.decoders import ByteLevel as ByteLevelDecoder
    from tokenizers.normalizers import NFC

    output_dir.mkdir(parents=True, exist_ok=True)

    log.info(f"Training BPE tokenizer on {input_path}")
    log.info(f"Vocab size: {vocab_size:,}")
    log.info(f"Special tokens: {len(SPECIAL_TOKENS)}")

    # Build tokenizer
    tokenizer = Tokenizer(BPE(unk_token="<UNK>"))

    # NFC normalization — handles unicode composed/decomposed forms
    tokenizer.normalizer = NFC()

    # Byte-level pre-tokenizer — handles any unicode without UNK tokens.
    # Same as GPT-2's approach — every byte is representable.
    tokenizer.pre_tokenizer = ByteLevel(add_prefix_space=False)
    tokenizer.decoder = ByteLevelDecoder()

    # No post-processor — BOS/EOS are NOT added automatically.
    # They must be added explicitly by the data pipeline where needed.
    # Automatic injection via TemplateProcessing corrupts chat-formatted
    # data by inserting tokens at positions the model does not expect.

    # Trainer
    trainer = BpeTrainer(
        vocab_size=vocab_size,
        min_frequency=min_frequency,
        special_tokens=SPECIAL_TOKENS,
        show_progress=True,
        initial_alphabet=ByteLevel.alphabet(),
    )

    # Train
    log.info("Training...")
    tokenizer.train_from_iterator(
        text_iterator(input_path),
        trainer=trainer,
        length=None,
    )

    # Verify special token IDs are correct
    for expected_id, token in enumerate(SPECIAL_TOKENS):
        actual_id = tokenizer.token_to_id(token)
        if actual_id != expected_id:
            log.warning(
                f"Special token ID mismatch: {token} "
                f"expected={expected_id}, actual={actual_id}"
            )

    # Save raw tokenizer
    tokenizer_path = output_dir / "slm_tokenizer.json"
    tokenizer.save(str(tokenizer_path))
    log.info(f"Tokenizer saved to {tokenizer_path}")

    # Save vocab and merges separately for inspection
    tokenizer.model.save(str(output_dir))
    log.info(f"Vocab and merges saved to {output_dir}")

    # Save special token definitions
    special_tokens_path = output_dir / "special_tokens.json"
    with open(special_tokens_path, "w") as f:
        json.dump(
            {token: i for i, token in enumerate(SPECIAL_TOKENS)},
            f, indent=2
        )
    log.info(f"Special tokens saved to {special_tokens_path}")

    # Save as HuggingFace PreTrainedTokenizerFast with chat template
    _save_as_hf_tokenizer(tokenizer, output_dir)

    # Print vocab stats
    vocab = tokenizer.get_vocab()
    log.info(f"Final vocab size: {len(vocab):,}")
    log.info(f"Special tokens verified: {len(SPECIAL_TOKENS)}")


def _save_as_hf_tokenizer(tokenizer, output_dir: Path) -> None:
    """
    Save the tokenizer as a HuggingFace PreTrainedTokenizerFast.

    Bakes in the Jinja2 chat template including {% generation %} /
    {% endgeneration %} tags required by trl's assistant_only_loss=True.

    Args:
        tokenizer: Trained tokenizers.Tokenizer instance.
        output_dir: Directory to save the HuggingFace tokenizer.
    """
    try:
        from transformers import PreTrainedTokenizerFast

        hf_tokenizer = PreTrainedTokenizerFast(
            tokenizer_object=tokenizer,
            bos_token="<BOS>",
            eos_token="<EOS>",
            unk_token="<UNK>",
            pad_token="<PAD>",
            # Use the explicit ADDITIONAL_SPECIAL_TOKENS list rather than a
            # positional slice of SPECIAL_TOKENS — reordering the structural
            # tokens would silently break a positional slice.
            additional_special_tokens=ADDITIONAL_SPECIAL_TOKENS,
        )

        hf_tokenizer.chat_template = CHAT_TEMPLATE

        hf_tokenizer.save_pretrained(str(output_dir))
        log.info(f"HuggingFace tokenizer saved to {output_dir}")
        log.info(f"Chat template baked in — apply_chat_template() ready")
        log.info(f"Generation tags included — assistant_only_loss=True supported")

    except Exception as e:
        log.error(f"Could not save HF tokenizer: {e}")
        raise


# ── CLI ────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Train SLM BPE tokenizer")
    parser.add_argument("--size", default=os.environ.get("SIZE", "125m"), help="Run size")
    parser.add_argument(
        "--input",
        type=Path,
        default=None,
        help="Input JSONL file (default: data/runs/<size>/validated/train.jsonl)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output directory (default: data/runs/<size>/tokenizer)",
    )
    parser.add_argument(
        "--vocab-size",
        type=int,
        default=32_000,
        help="Vocabulary size (default: 32000)",
    )
    parser.add_argument(
        "--min-frequency",
        type=int,
        default=2,
        help="Minimum token frequency (default: 2)",
    )
    args = parser.parse_args()

    args.input = args.input or (validated_dir(args.size) / "train.jsonl")
    args.output = args.output or tokenizer_dir(args.size)

    if not args.input.exists():
        log.error(f"Input file not found: {args.input}")
        log.error("Run: python validation/scripts/validate.py --size <size>")
        sys.exit(1)
    default_validated = validated_dir(args.size)
    if (
        args.input.parent == default_validated
        and not manifest_outputs_match(
            default_validated,
            output_pattern="*.json*",
        )
    ):
        raise RuntimeError(
            f"Validated tokenizer input is not manifest-complete: "
            f"{default_validated}"
        )

    input_signature = stable_digest(
        file_snapshot([args.input], root=args.input.parent)
    )
    contract = {
        "implementation_sha256": code_fingerprint(train_tokenizer),
        "vocab_size": args.vocab_size,
        "min_frequency": args.min_frequency,
        "special_tokens": SPECIAL_TOKENS,
        "normalizer": "NFC",
        "pre_tokenizer": "ByteLevel(add_prefix_space=False)",
        "chat_template": CHAT_TEMPLATE,
    }
    if manifest_matches(
        args.output,
        stage="tokenizer",
        contract=contract,
        input_signature=input_signature,
        output_pattern="*",
    ):
        log.info("Verified tokenizer manifest matches input/configuration — reusing")
        return

    partial_output = args.output.with_name(f".{args.output.name}.partial")
    backup_output = args.output.with_name(f".{args.output.name}.previous")
    if partial_output.exists():
        shutil.rmtree(partial_output)
    train_tokenizer(
        input_path=args.input,
        output_dir=partial_output,
        vocab_size=args.vocab_size,
        min_frequency=args.min_frequency,
    )
    write_manifest(
        partial_output,
        stage="tokenizer",
        contract=contract,
        input_signature=input_signature,
        output_pattern="*",
    )
    if backup_output.exists():
        shutil.rmtree(backup_output)
    if args.output.exists():
        args.output.replace(backup_output)
    try:
        partial_output.replace(args.output)
    except Exception:
        if backup_output.exists() and not args.output.exists():
            backup_output.replace(args.output)
        raise
    if backup_output.exists():
        shutil.rmtree(backup_output)

    log.info("Tokenizer training complete.")
    log.info(f"Next step: python tokenizer/test_tokenizer.py")


if __name__ == "__main__":
    main()
