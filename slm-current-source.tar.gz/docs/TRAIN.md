# Training

This guide restores a curated artifact run on a new GPU host and trains the
base, instruct, code, and chat model variants.

## Required inputs

| Input | Purpose |
|---|---|
| `SIZE` | Model profile: `mini`, `125m`, `350m`, or `1b` |
| `GPUS` | Number of visible GPUs used by configuration and training |
| `DATASET_SIZE` | Source dataset profile; defaults to `SIZE` |
| `DATASET_RUN_ID` / `RUN_ID` | Explicit source dataset artifact run |
| `DATA_DIR` | Persistent data and cache root on the GPU host |
| `.env` | AWS, Hugging Face, W&B, cache, results, and export configuration |

Populate the common environment settings, including required W&B API key and
project, and the credentials for the artifact backend used by restoration.
S3 can use SDK/instance-role credentials; HF uses Dataset credentials for text
and separate HF S3 credentials for Bucket objects.
The GPU host
must use an NVIDIA driver compatible with the repository's pinned CUDA 13
training stack.

## Prepare the host

Clone and configure the repository:

```bash
git clone https://github.com/tohio/slm.git
cd slm
cp .env.sample .env
vi .env
```

The `RUN_ID` comes from the final output of
[`curate-all`](CURATION.md#fresh-host-workflow).

## Complete workflow

On a fresh GPU host:

```bash
make train-all \
  SIZE=125m \
  GPUS=1 \
  RUN_ID=125m-YYYYMMDD-abcdef \
  DATA_DIR=/data/slm/data
```

`train-all` performs the following sequence:

1. Validates common environment settings (including W&B) and required Make inputs.
   Selected transfer code validates its backend credentials.
2. Installs the GPU environment and pinned CUDA training dependencies.
3. Restores the selected source-run artifacts (all tokenized splits, tokenizer,
   and metadata by default) identified by `DATASET_SIZE` and `DATASET_RUN_ID`.
4. Runs the dataset-free CUDA, BF16, compile, and generation acceptance gate.
5. Generates hardware-specific pretraining, SFT, and DPO configurations.
6. Pretrains the base model.
7. Validates the completed base checkpoint.
8. Prepares, trains, and validates the instruct SFT branch.
9. Trains and validates the independent code SFT branch.
10. Prepares, trains, and validates the DPO chat branch.

The target is for a new run only. If a pretraining output directory already
exists, it stops and directs the operator to the stage-specific resume
commands.

Evaluation, export, publication, and serving remain explicit operations after
training.

## Stage-by-stage workflow

This route is an alternative to `train-all`, not a follow-on setup sequence.

### Restore the curation run

```bash
make check-env
make setup-train \
  DATA_DIR=/data/slm/data \
  SIZE=125m \
  RUN_ID=125m-YYYYMMDD-abcdef

make test-gpu-gate
```

`setup-train` restores `tokenized`, `tokenizer`, and `metadata` by default.
Include `validated` in `ARTIFACT_STAGES` for final test-document completions.
Without a selected source RUN_ID, setup installs the environment only.
Pretraining uses the dataset-scoped tokenizer directly; no global copy is made.

### Generate training configurations

Generate recipes on the target GPU host:

```bash
make config-gen SIZE=125m GPUS=1
```

For an explicit hardware or VRAM policy:

```bash
make config-gen \
  SIZE=350m \
  GPUS=4 \
  GPU=h200 \
  MODE=conservative
```

Inspect the generated pretraining, SFT, and DPO YAML files before starting a
paid run.

`config-gen` also generates the DDP launch file internally when needed.
`GPUS` is passed directly to Accelerate as `--num_processes`. `GPUS=1` uses
one process; `GPUS>1` keeps the existing one-process-per-GPU DDP launch:

```bash
make pretrain SIZE=350m GPUS=4
```

### Pretrain the base model

Run the bounded readiness gate, then start a new run:

```bash
make test-pretrain-ready SIZE=125m GPUS=1
make pretrain SIZE=125m GPUS=1
```

Resume an interrupted run:

```bash
make test-pretrain-resume-ready SIZE=125m GPUS=1
make pretrain-resume SIZE=125m GPUS=1
```

The promoted checkpoint is:

```text
$RESULTS_DIR/runs/<size>/pretrain/final/
```

`pretrain_run_audit.json` records the resolved training configuration,
tokenizer fingerprint, tokenized-data identity, process count, and distributed
strategy. Resume requires an exact match and never falls back to a new run.

Pretraining windows are cut from one continuous BOS/document/EOS token stream.
Attention and position IDs do not reset at EOS: when a window spans documents,
a later document can attend to earlier documents in that window. This is the
intentional base-pretraining objective, not independent-example SFT packing.

The promoted `pretrain/final` checkpoint is consumed directly by post-training;
no embedding rows are reinitialized between pretraining and SFT.

### Train the instruct branch

```bash
make prepare-sft SIZE=125m
make sft-instruct SIZE=125m GPUS=1
make test-sft-instruct SIZE=125m
```

Resume:

```bash
make sft-instruct-resume SIZE=125m GPUS=1
```

The promoted checkpoint is:

```text
$RESULTS_DIR/runs/<size>/sft_instruct/final/
```

### Train the code branch

Code SFT starts from the completed instruct checkpoint:

```bash
make sft-code SIZE=125m GPUS=1
make test-sft-code SIZE=125m
```

Resume:

```bash
make sft-code-resume SIZE=125m GPUS=1
```

### Train the chat branch

DPO also starts from the completed instruct checkpoint:

```bash
make prepare-dpo SIZE=125m
make dpo-chat SIZE=125m GPUS=1
make test-dpo-chat SIZE=125m
```

Resume:

```bash
make dpo-chat-resume SIZE=125m GPUS=1
```

The code and chat branches are independent:

```text
pretrain/final
└── sft_instruct/final
    ├── sft_code/final
    └── dpo_chat/final
```

## Recovery checkpoint completeness

Resume verifies both the immutable run inputs **and** the selected recovery
checkpoint. `final/` is a model artifact, not a substitute for optimizer recovery.
Keep the run-root audit and the complete numbered checkpoint together:
model config and weights (all indexed shards), `trainer_state.json`, `optimizer.pt`,
`scheduler.pt`, and RNG state (`rng_state.pth` for one process or one
`rng_state_<rank>.pth` per DDP rank). FP16 CUDA recovery also needs `scaler.pt`.
The saved global step must match the checkpoint number. Native loading remains
responsible for validating serialized state contents; file presence alone is not
a numerical reproducibility guarantee across different hardware or runtimes.

The latest numeric checkpoint is selected by default. If it is incomplete, the
command stops and reports missing files; it does not silently reset optimizer
state or select another step. Restore that checkpoint fully, or explicitly select
a verified earlier checkpoint under the same run output:

```bash
make pretrain-resume SIZE=125m GPUS=1 \
  RESUME_CHECKPOINT=/data/slm/results/runs/125m/pretrain/checkpoint-1000
```

The same selector works with `pretrain-resume-preflight`, `sft-instruct-resume`,
`sft-code-resume`, and `dpo-chat-resume`. The corresponding Python entry points
accept `--resume /path/to/checkpoint-N`. Preserve any best-checkpoint artifacts
referenced by Trainer state as well; a transfer must not be limited to weights.

SFT/DPO accept positive fractional `epochs`. Update planning rounds batches and
accumulation as the pinned Trainer does, then takes the ceiling after multiplying
by epochs; a positive `max_steps` overrides epoch-derived planning. Warmup uses
the same planned update count. Existing integer-epoch recipes are unchanged.

## Post-training identity and resume

Instruct/code SFT and DPO require the tokenizer bundled with their input
checkpoint, in `tokenizer/` or at the checkpoint root. They never substitute a
model-size tokenizer. Pretraining copies the chosen dataset tokenizer into its
final checkpoint, so cross-size reuse continues through post-training.

SFT verifies preparation-manifest checksums, stage/size, complete JSONL hashes
and counts, and normalized prompt separation before sampling or constructing a
trainer. DPO verifies its preference manifest and the actual instruct tokenizer
and rendering template. Both validate the whole input before `max_samples`.

The immutable run audit binds the resolved recipe, model architecture, input
checkpoint config/weight hashes, tokenizer/template, prepared data, and process
count. DPO also binds its original fixed reference checkpoint. Resume must find
a complete numbered recovery checkpoint and a matching audit; a new run into an occupied directory
is rejected. `--preflight-only` does not replace the run audit. Use it with
`--resume` when checking an interrupted run.

Older SFT/DPO audits without a checksum-verified run contract cannot establish
resume compatibility. Preserve their artifacts; do not invent an audit or delete
it to bypass the check. Start an explicitly new output run when redoing that
stage. Pretraining retains its existing audit format.

DPO preparation and training must use the same instruct checkpoint/config.
`DPO_CHAT_CONFIG` selects the recipe and optional `DPO_BASE_MODEL` overrides its
parent for both Make paths. A change to the tokenizer or standalone template
requires intentional DPO re-preparation; old template-incomplete fingerprints
are not treated as equivalent.

## Evaluate and export

Evaluate completed variants:

```bash
make eval-base SIZE=125m
make eval-instruct SIZE=125m
make eval-code SIZE=125m
make eval-chat SIZE=125m
```

Build and validate native local packages:

```bash
make export-local SIZE=125m
```

Run the clean native load, parity, and generation acceptance gate for one
variant:

```bash
make test-export-acceptance \
  SIZE=125m \
  EXPORT_VARIANT=base
```

In an environment with vLLM installed, exercise the produced package through
offline generation:

```bash
make test-vllm-export \
  SIZE=125m \
  EXPORT_VARIANT=base
```

Publish all validated variants using the configured Hugging Face account:

```bash
make export SIZE=125m
```

## Troubleshooting

For CUDA, dependency, checkpoint, data-restore, and training-stage failures,
see [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md).

## See Also

- [Curation](CURATION.md)
- [Testing](TESTING.md)
- [Hardware guide](HARDWARE.md)
- [Command reference](COMMANDS.md)
- [Pretraining component guide](../pretrain/README.md)
- [SFT component guide](../finetune/README.md)
- [DPO component guide](../alignment/README.md)

## Test evaluation and cross-size inputs

[Pretraining data and reuse](PRETRAINING_DATA.md) documents final-only test,
`SIZE` versus `DATASET_SIZE`, matched tokenizer/binary/metadata restoration, and
model-specific budgets. Generic probes remain lightweight, separate, and
non-gating. All sizes use the same explicit `GPUS=N` configuration flow except
for the separate Smoke path.

[Tool calling](TOOL_CALLING.md) describes the optional reviewed SFT input and
single-call chat runtime. It uses the existing trainer and tool vocabulary.


## Portable final-checkpoint provenance

New pretraining, SFT and DPO finals include `training_provenance.json`. It contains
small, checksum-verified stage audits, prepared-data manifests, checkpoint
fingerprints and pretraining corpus metadata—not ancestor model weights or corpus
copies. This history is carried forward at each branch, so export does not need
the historical absolute parent paths on the original training host.

Model cards use the audited `dataset_size` and dataset run rather than assuming
`SIZE` identifies the source corpus. Full source-corpus counts, selected unique
training tokens, recorded consumed tokens and the planned schedule are reported
separately. New pretraining runs count actual training inputs; legacy resumes
without full-run counting report consumption as unrecorded, never infer it from
an advanced step counter. See [export inputs and legacy recovery](../export/README.md#portable-provenance).
