# Troubleshooting

This guide covers common environment, data-access, curation-resume, storage,
and artifact-transfer failures.

## Environment configuration

Check the common settings, including required `HF_TOKEN`, `WANDB_API_KEY`, and
`WANDB_PROJECT`. W&B is not optional. Storage credentials and `HF_USERNAME` are
checked by selected transfers and model publication, not required for unused
services. Do not fill unused fields with dummy credentials:

```bash
make check-env
.venv/bin/python infra/verify_environment.py --profile curation
```

These are diagnostic commands; normal setup/entry points invoke the relevant
checks internally. On a training host select `--profile training` instead.
`INSTALLER=uv` or `conda` requires that installer to be available. Do not mix a
conda prefix and a pip/uv venv at `.venv`, or install both role stacks together.

## Hugging Face dataset access

If a source returns `401`, `403`, a gated-repository error, or a
repository-not-found error, confirm access with the same account represented
by `HF_TOKEN`:

```bash
.venv/bin/python - <<'PY'
import os

from dotenv import load_dotenv
from huggingface_hub import HfApi

load_dotenv()
api = HfApi(token=os.environ["HF_TOKEN"])

for repo_id in (
    "bigcode/the-stack-dedup",
    "bigcode/the-stack-smol",
    "nvidia/Nemotron-CC-Math-v1",
):
    info = api.dataset_info(repo_id)
    print(repo_id, info.sha)
PY
```

If the check fails, sign in to that Hugging Face account, accept the dataset's
terms, and rerun it. Creating another token does not grant access to an account
that has not accepted the terms.

## Storage and resource failures

Check capacity, inodes, memory, and the open-file limit:

```bash
df -h /data
df -ih /data
free -h
ulimit -n
```

Do not delete stage manifests to recover space while expecting the stage to
remain resumable. The disk setup procedure is in
[`DISK_SETUP.md`](DISK_SETUP.md).

## Resume interrupted curation

Rerun the same command with the same profile and configuration:

```bash
make curate SIZE=125m WORKERS=62
```

Manifest-complete stages with matching input, implementation, configuration,
and output signatures are reused. Use `FORCE=1` only for a specifically
diagnosed stale or invalid stage; it is not part of normal resume.

Inspect a source without rebuilding it:

```bash
python curator/scripts/sample_source.py \
  --size 125m \
  --stage raw \
  --source wikipedia \
  --limit 10
```

An intact test split with changed blend inputs/configuration is not a successful
resume. Blend now rejects that mismatch. Use a new data root for a new corpus;
do not delete `test_contract.json` or `_SUCCESS.json` to force new membership.
Restoring/training from retained artifacts does not require curation scratch.

## Tokenization or post-training identity failures

A `.bin` without a matching verified JSON sidecar/completion manifest is not a
completed stage. After repairing code, rerun the existing tokenization command
on the same validated inputs/tokenizer; the split writer replaces the orphaned
derived binary. Do not manufacture metadata to mark it complete.

SFT verifies full train/validation hashes, record counts, stage/size, and actual
normalized prompt separation. Restore the original prepared files or deliberately
re-prepare a new input and start a new training output. Matching row shapes alone
are not evidence that validation is disjoint.

DPO preparation requires the actual instruct checkpoint tokenizer. A template
change, including `chat_template.jinja`, requires intentional re-preparation.
Use the same `DPO_CHAT_CONFIG`/`DPO_BASE_MODEL` for preparation and training.
Missing checkpoint tokenizers must be restored with the checkpoint; another
same-size tokenizer is not a substitute.

SFT/DPO resume requires a numbered checkpoint plus the original immutable run
audit. Changed recipe/data/parent/reference/tokenizer inputs are rejected before
the audit can be overwritten. Legacy audits without a run contract cannot be
promoted into evidence of compatibility. Preserve the old run and use a new
output root for an intentionally new run. Export likewise requires authentic
size/stage provenance; changing CLI labels does not make Mini exportable.

## Stage validation failures

Run the gate for the stage that just completed:

```bash
make test-curator SIZE=125m
make test-validate SIZE=125m
make tokenizer-test SIZE=125m
make test-data-pipeline SIZE=125m
```

These commands inspect existing outputs. See [`TESTING.md`](TESTING.md) for
artifact requirements and the complete test policy.

## Artifact upload failures

Load `.env`, verify the AWS identity, and confirm access to the configured
prefix:

```bash
set -a
source .env
set +a

aws sts get-caller-identity
aws s3 ls "s3://$S3_BUCKET/$S3_PREFIX/"
```

Resume the upload with the same stage set:

```bash
make artifacts-upload \
  SIZE=125m \
  ARTIFACT_STAGES="validated,tokenized,tokenizer,metadata"
```

The upload reuses the current day's local `RUN_ID`. For a later upload to the
same artifact run, pass the recorded value explicitly:

```bash
make artifacts-upload \
  SIZE=125m \
  RUN_ID=125m-YYYYMMDD-abcdef \
  ARTIFACT_STAGES="validated,tokenized,tokenizer,metadata"
```

## HF artifact failures

Dataset transfers use `HF_DATASET_REPO` and `HF_TOKEN`. Bucket objects use
`HF_ARTIFACT_BUCKET=namespace/bucket` with **HF-generated** S3 keys, not AWS keys
or the Hub token. Only credentials for the selected stages are needed. Confirm
Bucket creation/permissions and that Dataset access uses the intended account.
See [HF routing](PRETRAINING_DATA.md#s3-and-hugging-face-routing).

A failed restore leaves `_RESTORE_PENDING.json` so training cannot consume a
partial dataset. Repeat the same run/stages; use `ARTIFACT_OVERWRITE=1` for
corrupt same-size local files. Do not delete the marker to bypass verification.

## GPU environment failures

`setup-train` is GPU-host setup. A missing `nvidia-smi` produces an explicit
unsupported-host error before installation. CPU-executed model tests require an
already installed training environment; do not invoke this command as a CPU-only
installer. See [testing](TESTING.md#cpu-model-and-training-contracts).

On a training host, require the CUDA contract and then run the dataset-free
acceptance gate:

```bash
.venv/bin/python infra/verify_environment.py --require-cuda
make test-gpu-gate
```

See [`HARDWARE.md`](HARDWARE.md) for the supported hardware contract.

## See Also

- [Testing](TESTING.md)
- [Disk setup](DISK_SETUP.md)
- [Command reference](COMMANDS.md)
- [Curation component guide](../curator/README.md)


## Incomplete recovery or relocated export

An incomplete newest `checkpoint-N` is an error even when its model weights load.
Restore optimizer, scheduler, Trainer and RNG files (and the FP16 scaler when
applicable), or select a verified earlier checkpoint under the same run with
`RESUME_CHECKPOINT=...`. Do not delete only the failed checkpoint and assume the
next one is a valid continuation. See [recovery details](TRAIN.md#recovery-checkpoint-completeness).
Raw completion additionally requires its sampler cursor and bundled best-model snapshot;
legacy raw state without a cursor cannot be upgraded into exact continuation.

A relocated final should include `training_provenance.json`. For a legacy final
without that bundle, use verified original ancestors through repeated
`--provenance-parent` export arguments; do not edit old audit paths/hashes or
substitute another model-size corpus. See [portable export](../export/README.md#portable-provenance).

Training setup refuses an existing unwritable project path. Grant access to that
specific directory or choose another `DATA_DIR`; do not recursively change the
ownership of a shared parent such as `/mnt`.
