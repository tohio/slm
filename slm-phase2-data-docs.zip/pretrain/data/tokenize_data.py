"""
pretrain/data/tokenize_data.py
--------------------------
Tokenize the validated JSONL datasets into memory-mapped binary files
for efficient pretraining.

Tokenizes once, saves to disk as a flat array of uint16 token IDs.
During training, each dataset is loaded with np.memmap — zero-copy,
constant memory regardless of dataset size, and much faster than
tokenizing on the fly.

Format:
    Single flat binary file of uint16 token IDs per split.
    Documents are bracketed by BOS at start and EOS at end.
    No padding — sequences are packed end-to-end.

    [BOS, doc1_tok1, doc1_tok2, ..., doc1_tokN, EOS,
     BOS, doc2_tok1, doc2_tok2, ..., doc2_tokM, EOS, ...]

    uint16 supports vocab sizes up to 65,535 — sufficient for 32k vocab.

Output:
    data/runs/<size>/tokenized/train.bin    — token IDs as uint16
    data/runs/<size>/tokenized/train.json   — metadata (n_tokens, n_docs, dtype, vocab_size)
    data/runs/<size>/tokenized/val.bin      — same, for validation split
    data/runs/<size>/tokenized/val.json

Inputs:
    By default both validated/train.jsonl and validated/val.jsonl are tokenized.
    The val split was produced upstream by the curator's blend stage as a
    uniform random sample of the shuffled documents, so val and train come
    from the same distribution.

Tokenizer:
    Uses the raw tokenizers.Tokenizer from slm_tokenizer.json directly —
    not PreTrainedTokenizerFast. This is intentional: bulk tokenization
    only needs text → token IDs conversion. The raw tokenizer is faster
    and has no dependency on tokenizer_config.json or the chat_template,
    which are only needed at training and inference time.

Performance notes:
    - Tokenizer is loaded once per worker process (not per document)
    - Documents are batched into chunks before dispatch to amortise IPC overhead
    - Tokens are streamed directly to disk as chunks complete via
      pool.imap_unordered — peak RAM per split is O(chunk_size × avg_tokens),
      not O(shard_size) or O(corpus_size).
    - One persistent mp.Pool for both splits — no pool startup cost per split

Usage:
    python pretrain/data/tokenize_data.py
    python pretrain/data/tokenize_data.py --size 125m
python pretrain/data/tokenize_data.py --train data/runs/125m/validated/train.jsonl \\
    python pretrain/data/tokenize_data.py --workers 24
"""

import argparse
import hashlib
import json
import logging
import multiprocessing as mp
import os
import sys
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from tqdm import tqdm

load_dotenv()

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from config.paths import validated_dir, tokenizer_dir, tokenized_dir, BASE_DATA_DIR

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

DATA_DIR = BASE_DATA_DIR
TOKENIZED_DIR = tokenized_dir("125m")

# uint16 supports up to this vocab size (exclusive). If our tokenizer ever
# exceeds this we must switch the binary format to uint32 — silently
# overflowing uint16 would corrupt every token ID above 65535.
UINT16_MAX_VOCAB = 65_536

# Bump this whenever the binary token stream format changes.
# Used to prevent silently reusing stale tokenized files.
TOKENIZED_FORMAT_VERSION = "bos_doc_eos_v1"

# Global tokenizer instance — loaded once per worker process via initializer,
# not once per document. Avoids one tokenizer load per document in the
# original code.
_worker_tokenizer = None
_worker_bos_id    = None
_worker_eos_id    = None


def tokenizer_fingerprint(tokenizer_path: Path) -> str:
    """
    Return SHA256 of the tokenizer's canonical serialized form.

    Hashes the loaded tokenizer's behavior, not the on-disk bytes.
    Two files that load to the same tokenizer (e.g., re-saved with
    different whitespace) produce the same fingerprint; two files
    that produce different IDs for the same input cannot collide.
    """
    from tokenizers import Tokenizer
    tok = Tokenizer.from_file(str(tokenizer_path))
    return hashlib.sha256(tok.to_str().encode("utf-8")).hexdigest()


def _validate_tokenizer(tokenizer_path: Path) -> tuple[int, int, int]:
    """
    Load and validate the tokenizer in one pass.

    Returns (vocab_size, bos_id, eos_id).

    Raises:
        RuntimeError: if vocab is too large for uint16, or if BOS/EOS
            special tokens are missing from the tokenizer.

    Combines what was previously two separate tokenizer loads
    (vocab check + special-token lookup) into one. Negligible
    perf benefit, but cleaner — both reads happen against the
    same in-memory tokenizer instance.
    """
    from tokenizers import Tokenizer
    tok = Tokenizer.from_file(str(tokenizer_path))

    vocab_size = tok.get_vocab_size()
    if vocab_size >= UINT16_MAX_VOCAB:
        raise RuntimeError(
            f"Tokenizer vocab_size={vocab_size:,} does not fit in uint16 "
            f"(max {UINT16_MAX_VOCAB - 1:,}). Either reduce the vocab size "
            f"or switch the binary format in tokenize_data.py and "
            f"dataset.py to uint32."
        )

    bos_id = tok.token_to_id("<BOS>")
    eos_id = tok.token_to_id("<EOS>")
    if bos_id is None:
        raise RuntimeError("Tokenizer does not contain required <BOS> token")
    if eos_id is None:
        raise RuntimeError("Tokenizer does not contain required <EOS> token")

    log.info(f"Tokenizer vocab size: {vocab_size:,} (fits in uint16)")
    return vocab_size, bos_id, eos_id


def _worker_init(tokenizer_path: str, bos_id: int, eos_id: int) -> None:
    """
    Initialize the tokenizer once per worker process.

    Called by mp.Pool as the initializer — runs once when each worker
    process starts, not once per task. The tokenizer is stored as a
    module-level global so all tasks in that worker reuse it.

    Uses the raw tokenizers.Tokenizer (not PreTrainedTokenizerFast) —
    the chat_template and tokenizer_config.json are not needed here.
    """
    global _worker_tokenizer, _worker_bos_id, _worker_eos_id
    from tokenizers import Tokenizer
    _worker_tokenizer = Tokenizer.from_file(tokenizer_path)
    _worker_bos_id    = bos_id
    _worker_eos_id    = eos_id


def _tokenize_chunk(texts: list[str]) -> tuple[list[int], int]:
    """
    Tokenize a chunk of documents.

    Returns:
        (tokens, n_docs)

    n_docs is counted from the input chunk length, not by scanning for EOS,
    because document text may itself contain strings that tokenize to EOS.
    """
    global _worker_tokenizer, _worker_bos_id, _worker_eos_id

    tokens: list[int] = []
    encodings = _worker_tokenizer.encode_batch(texts, add_special_tokens=False)

    for enc in encodings:
        tokens.append(_worker_bos_id)
        tokens.extend(enc.ids)
        tokens.append(_worker_eos_id)

    return tokens, len(texts)


def _count_docs(path: Path) -> int:
    """
    Count documents (non-empty lines) in a JSONL file.

    This is a separate pass over the input so tqdm can show an ETA during
    the main tokenization loop. For a multi-hour run at 1b scale the extra
    ~30 seconds of counting is a good trade for actionable progress
    reporting. For small runs the overhead is negligible.
    """
    return sum(1 for line in open(path) if line.strip())


def _chunked(iterable, size: int):
    """Yield successive size-sized chunks from iterable."""
    buf: list = []
    for item in iterable:
        buf.append(item)
        if len(buf) >= size:
            yield buf
            buf = []
    if buf:
        yield buf


def _tokenize_split(
    input_path: Path,
    output_dir: Path,
    split: str,
    pool: mp.Pool,
    bos_id: int,
    eos_id: int,
    tokenizer_path: Path,
    chunk_size: int,
) -> dict:
    """
    Tokenize one JSONL file to {output_dir}/{split}.bin + .json.

    Streams through the input file, batching documents into chunks and
    dispatching via pool.imap_unordered. Results arrive in whatever order
    workers finish — the order of documents in the output binary differs
    from the input, but since documents are separated by EOS and position
    within the binary carries no meaning, this has no effect on training.

    Returns the metadata dict written to disk.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    bin_path  = output_dir / f"{split}.bin"
    meta_path = output_dir / f"{split}.json"

    current_tokenizer_sha256 = tokenizer_fingerprint(tokenizer_path)

    if bin_path.exists() and meta_path.exists():
        with open(meta_path) as f:
            meta = json.load(f)

        saved_tokenizer_sha256 = meta.get("tokenizer_sha256")
        saved_format_version = meta.get("format_version")

        if saved_tokenizer_sha256 != current_tokenizer_sha256:
            raise RuntimeError(
                f"[{split}] Existing tokenized data was created with a different "
                f"or unknown tokenizer.\n"
                f"Existing tokenizer_sha256: {saved_tokenizer_sha256}\n"
                f"Current tokenizer_sha256:  {current_tokenizer_sha256}\n"
                f"Delete {bin_path} and {meta_path}, or run a clean tokenize target."
            )

        if saved_format_version != TOKENIZED_FORMAT_VERSION:
            raise RuntimeError(
                f"[{split}] Existing tokenized data uses an old or unknown format.\n"
                f"Existing format_version: {saved_format_version}\n"
                f"Current format_version:  {TOKENIZED_FORMAT_VERSION}\n"
                f"Delete {bin_path} and {meta_path}, or run a clean tokenize target."
            )

        log.info(
            f"[{split}] Already tokenized and tokenizer/format match: {bin_path}"
        )
        return meta

    log.info(f"[{split}] Counting documents in {input_path}...")
    n_docs_total = _count_docs(input_path)
    log.info(f"[{split}] Total documents: {n_docs_total:,}")

    n_tokens    = 0
    n_processed = 0

    with open(bin_path, "wb") as bin_file, open(input_path) as f:
        # Read and chunk documents lazily — no full-corpus list in RAM.
        def _doc_iter():
            for line in f:
                record = json.loads(line)
                text = record.get("text", "").strip()
                if text:
                    yield text

        chunks = _chunked(_doc_iter(), chunk_size)

        # imap_unordered streams results back as each worker finishes a
        # chunk. The token list for each chunk is written immediately and
        # discarded, so peak RAM is bounded by (pool size × chunk size).
        pbar = tqdm(total=n_docs_total, desc=f"Tokenizing {split}", unit="doc")
        for tokens, docs_in_chunk in pool.imap_unordered(_tokenize_chunk, chunks):
            _write_tokens(tokens, bin_file)
            n_tokens += len(tokens)
            n_processed += docs_in_chunk
            pbar.update(docs_in_chunk)
        pbar.close()

    log.info(f"[{split}] Total tokens:     {n_tokens:,} ({n_tokens / 1e9:.2f}B)")
    log.info(f"[{split}] Total documents:  {n_processed:,}")
    log.info(f"[{split}] Avg tokens/doc:   {n_tokens // max(n_processed, 1):,}")
    log.info(f"[{split}] Binary size:      {bin_path.stat().st_size / 1e9:.2f} GB")

    meta = {
        "n_tokens":  n_tokens,
        "n_docs":    n_processed,
        "bos_id":    bos_id,
        "eos_id":    eos_id,
        "dtype":     "uint16",
        "split":     split,
        "input":     str(input_path),
        "tokenizer": str(tokenizer_path),
        "tokenizer_sha256": current_tokenizer_sha256,
        "format_version": TOKENIZED_FORMAT_VERSION,
    }

    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    log.info(f"[{split}] Metadata saved:   {meta_path}")

    return meta


def _write_tokens(tokens: list[int], bin_file) -> None:
    """Write a flat list of token IDs to the binary file as uint16."""
    arr = np.array(tokens, dtype=np.uint16)
    bin_file.write(arr.tobytes())


def verify_dataset(bin_path: Path, meta_path: Path) -> None:
    """Quick sanity check on the tokenized dataset."""
    with open(meta_path) as f:
        meta = json.load(f)

    if "bos_id" not in meta:
        raise RuntimeError(f"{meta_path} missing bos_id metadata")

    arr = np.memmap(str(bin_path), dtype=np.uint16, mode="r")

    log.info("=== Dataset Verification ===")
    log.info(f"  File:         {bin_path}")
    log.info(f"  Format ver:   {meta.get('format_version', '<unknown>')}")
    log.info(f"  Shape:        {arr.shape}")
    log.info(f"  N tokens:     {len(arr):,} (expected {meta['n_tokens']:,})")
    log.info(f"  Min token ID: {arr.min()}")
    log.info(f"  Max token ID: {arr.max()}")
    
    bos_count = int((arr == meta["bos_id"]).sum())
    eos_count = int((arr == meta["eos_id"]).sum())
    
    log.info(f"  BOS count:    {bos_count:,} (>= n_docs={meta['n_docs']:,})")
    log.info(f"  EOS count:    {eos_count:,} (>= n_docs={meta['n_docs']:,})")  
    log.info(f"  First 20 IDs: {arr[:20].tolist()}")

    assert len(arr) == meta["n_tokens"], "Token count mismatch"

    if bos_count < meta["n_docs"]:
        raise RuntimeError(
            f"BOS count too small: BOS={bos_count:,}, n_docs={meta['n_docs']:,}"
        )

    if eos_count < meta["n_docs"]:
        raise RuntimeError(
            f"EOS count too small: EOS={eos_count:,}, n_docs={meta['n_docs']:,}"
        )

    # Layout check: a bos_doc_eos_v1 binary must start with BOS.
    # Catches the case where BOS prepending is broken in a way that
    # still produces the right BOS count but wrong layout.
    if int(arr[0]) != meta["bos_id"]:
        raise RuntimeError(
            f"First token is {int(arr[0])}, expected BOS={meta['bos_id']}. "
            f"Binary layout is wrong — format_version={meta.get('format_version')!r} "
            f"requires BOS at position 0."
        )

    log.info("  ✓ Verification passed")


def main():
    parser = argparse.ArgumentParser(description="Tokenize dataset for pretraining")
    parser.add_argument("--size", default=os.environ.get("SIZE", "125m"), help="Run size")
    parser.add_argument(
        "--train",
        type=Path,
        default=None,
        help="Input train JSONL file",
    )
    parser.add_argument(
        "--val",
        type=Path,
        default=None,
        help="Input val JSONL file (skipped if missing)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output directory",
    )
    parser.add_argument(
        "--tokenizer",
        type=Path,
        default=None,
        help="Path to slm_tokenizer.json (raw BPE tokenizer)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=max(1, mp.cpu_count() - 2),
        help="Number of parallel workers. Default: cpu_count - 2",
    )
    parser.add_argument(
        "--chunk-size",
        type=int,
        default=256,
        help="Documents per worker task. Higher = less IPC overhead. Default: 256",
    )
    parser.add_argument(
        "--verify",
        action="store_true",
        help="Verify output after tokenization",
    )
    args = parser.parse_args()

    run_validated_dir = validated_dir(args.size)
    args.train = args.train or (run_validated_dir / "train.jsonl")
    args.val = args.val or (run_validated_dir / "val.jsonl")
    args.output = args.output or tokenized_dir(args.size)
    args.tokenizer = args.tokenizer or (tokenizer_dir(args.size) / "slm_tokenizer.json")

    # Pre-flight checks — fail with clear messages before spawning the pool
    if not args.train.exists():
        log.error(f"Train input not found: {args.train}")
        log.error("Run: make validate SIZE=<size>")
        sys.exit(1)

    if not args.tokenizer.exists():
        log.error(f"Tokenizer not found: {args.tokenizer}")
        log.error("Run: make tokenizer SIZE=<size> && make tokenizer-upload SIZE=<size>")
        log.error("Or:  make tokenizer-download SIZE=<size>")
        sys.exit(1)

    # Single-pass tokenizer validation: vocab size + special token IDs.
    # Fails fast if the tokenizer is unusable, before spawning workers.
    _, bos_id, eos_id = _validate_tokenizer(args.tokenizer)
    log.info(f"Special token IDs: BOS={bos_id}, EOS={eos_id}")

    val_available = args.val.exists()
    if not val_available:
        log.warning(
            f"Val input not found: {args.val}\n"
            f"Only train will be tokenized. The curator's blend stage produces "
            f"both train.jsonl and val.jsonl — re-run 'make curate' to get val."
        )

    log.info(f"Train:      {args.train}")
    log.info(f"Val:        {args.val if val_available else '(not found, skipping)'}")
    log.info(f"Output:     {args.output}")
    log.info(f"Tokenizer:  {args.tokenizer}")
    log.info(f"Workers:    {args.workers}")
    log.info(f"Chunk size: {args.chunk_size}")

    tokenizer_path_str = str(args.tokenizer)

    # One persistent pool for both splits — avoids pool startup cost twice.
    with mp.Pool(
        processes=args.workers,
        initializer=_worker_init,
        initargs=(tokenizer_path_str, bos_id, eos_id),
    ) as pool:
        _tokenize_split(
            input_path=args.train,
            output_dir=args.output,
            split="train",
            pool=pool,
            bos_id=bos_id,
            eos_id=eos_id,
            tokenizer_path=args.tokenizer,
            chunk_size=args.chunk_size,
        )

        if val_available:
            _tokenize_split(
                input_path=args.val,
                output_dir=args.output,
                split="val",
                pool=pool,
                bos_id=bos_id,
                eos_id=eos_id,
                tokenizer_path=args.tokenizer,
                chunk_size=args.chunk_size,
            )

    if args.verify:
        verify_dataset(
            bin_path=args.output / "train.bin",
            meta_path=args.output / "train.json",
        )
        if val_available:
            verify_dataset(
                bin_path=args.output / "val.bin",
                meta_path=args.output / "val.json",
            )

    log.info("Tokenization complete.")
    log.info('Next step: make artifacts-upload SIZE=<size> DATE=YYYY-MM-DD ARTIFACT_STAGES="raw,curated,validated,tokenized,tokenizer"')


if __name__ == "__main__":
    main()