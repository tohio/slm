"""
export/export.py
-----------------
Export a trained SLM checkpoint to the HuggingFace Hub.

Registers the custom SLMConfig and SLMForCausalLM with AutoConfig and
AutoModelForCausalLM so the model can be loaded anywhere with:

    from transformers import AutoModelForCausalLM, AutoTokenizer
    model = AutoModelForCausalLM.from_pretrained(
        "<username>/slm-125m", trust_remote_code=True,
    )

Four variants are exported per model size:

    Variant     Checkpoint                                    Hub repo
    --------    ----------                                    --------
    base        results/runs/{size}/pretrain/final                      <user>/slm-{size}
    instruct    results/runs/{size}/sft_instruct/final                      <user>/slm-{size}-instruct
    chat        results/runs/{size}/dpo_chat/final                           <user>/slm-{size}-chat
    code        results/runs/{size}/sft_code/final                      <user>/slm-{size}-code

Data mix and token targets are imported from config/data_mix.py — the
single source of truth for design intent. The model card additionally
loads data/runs/{size}/curated/blend_stats.json (if present and matching --size) to
render the realized per-source breakdown alongside the design targets,
so the published card reflects what actually shipped — not just what
was planned. Falls back to design-only with a caveat note if blend_stats
is missing or scale-mismatched.

Remote-code bundling:
    Export writes the architecture files directly into the checkpoint root and
    config.json declares auto_map entries pointing at config.SLMConfig and
    model.SLMForCausalLM.

    The root layout is required for compatibility with Transformers dynamic
    remote-code loading in environments that expect auto_map values in the
    form module.ClassName.
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config import (                                                # noqa: E402
    DATA_MIX, CODE_SUBMIX, dataset_link, corpus_tokens_display,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

HF_USERNAME = os.environ.get("HF_USERNAME")
HF_TOKEN    = os.environ.get("HF_TOKEN", "")
RESULTS_DIR = Path(os.environ.get("RESULTS_DIR", "results"))
DATA_DIR    = Path(os.environ.get("DATA_DIR", "data"))

# blend_stats.json is written by curator/scripts/curate.py at the end of the
# blend stage. Reading from data/runs/<size>/curated/ matches the curator's output
# location regardless of how DATA_DIR is set.
# Blend stats path is target-scoped; see _load_blend_stats(size).

REPO_ROOT   = Path(__file__).resolve().parents[1]
MODEL_PKG_DIR = REPO_ROOT / "model"

# Architecture source files bundled into the checkpoint root for Hub remote code.
BUNDLED_SOURCE_FILES = [
    "config.py",
    "model.py",
    "block.py",
    "attention.py",
    "mlp.py",
    "norm.py",
]


VARIANTS: dict[str, dict] = {
    "base": {
        "checkpoint":    lambda size: RESULTS_DIR / "runs" / size / "pretrain" / "final",
        "hub_suffix":    "",
        "description":   "base pretrained model",
        "pipeline_tag":  "text-generation",
    },
    "instruct": {
        "checkpoint":    lambda size: RESULTS_DIR / "runs" / size / "sft_instruct" / "final",
        "hub_suffix":    "-instruct",
        "description":   "instruction-tuned via instruct SFT + response-control",
        "pipeline_tag":  "text-generation",
    },
    "chat": {
        "checkpoint":    lambda size: RESULTS_DIR / "runs" / size / "dpo_chat" / "final",
        "hub_suffix":    "-chat",
        "description":   "chat-aligned from instruct via general DPO preference learning",
        "pipeline_tag":  "text-generation",
    },
    "code": {
        "checkpoint":    lambda size: RESULTS_DIR / "runs" / size / "sft_code" / "final",
        "hub_suffix":    "-code",
        "description":   "code-specialized from instruct via code SFT",
        "pipeline_tag":  "text-generation",
    },
}
def metadata_dir(size: str) -> Path:
    """Return the local metadata artifact directory for a model size."""
    return Path(os.environ.get("DATA_DIR", "data")) / "runs" / size / "metadata"


def curated_dir(size: str) -> Path:
    """Return the legacy curated artifact directory for a model size."""
    return Path(os.environ.get("DATA_DIR", "data")) / "runs" / size / "curated"


def tokenizer_dir(size: str) -> Path:
    """Return the tokenizer artifact directory for a model size."""
    return Path(os.environ.get("DATA_DIR", "data")) / "runs" / size / "tokenizer"


def _load_blend_stats(size: str) -> dict:
    """Load curation blend stats when available.

    Preferred location:
      data/runs/{size}/metadata/blend_stats.json

    Legacy fallback:
      data/runs/{size}/curated/blend_stats.json
    """
    candidates = [
        metadata_dir(size) / "blend_stats.json",
        curated_dir(size) / "blend_stats.json",
    ]

    for blend_stats_path in candidates:
        if blend_stats_path.exists():
            with blend_stats_path.open("r", encoding="utf-8") as f:
                return json.load(f)

    return {}


def _format_data_mix_table(size: str) -> str:
    """
    Render the pretraining data mix as a markdown table.

    If data/runs/{size}/curated/blend_stats.json exists and matches `size`, the table
    shows both target % and realized % per source, so the model card
    reflects what actually shipped in the published corpus. Otherwise it
    falls back to a design-target-only view with a caveat note that the
    realized mix may differ.

    Top-level vs code sub-sources:
        DATA_MIX has a logical "code" bucket — the actual code
        sources live in CODE_SUBMIX. blend_stats.json's source_mix dict
        contains the 5 expanded code sub-sources (no "code" entry). To
        render correctly we expand "code" into its sub-sources here when
        rendering, with realized% pulled from blend_stats per-source.
    """
    stats = _load_blend_stats(size)

    if not stats:
        # Design-only fallback: render DATA_MIX percentages without
        # realized numbers, plus a caveat that reality may have drifted.
        lines = [
            "| Source | Target Share | Link |",
            "|---|---|---|",
        ]
        for name, entry in DATA_MIX.items():
            if name == "code":
                code_top_pct = entry["pct"]
                for code_name, code_entry in CODE_SUBMIX.items():
                    target_pct = (code_entry["pct"] / 100.0) * code_top_pct
                    lines.append(
                        f"| `{code_name}` | {target_pct:.2f}% | "
                        f"{dataset_link(code_entry)} |"
                    )
                continue

            lines.append(f"| `{name}` | {entry['pct']:.1f}% | {dataset_link(entry)} |")
        lines.append("")
        lines.append(
            "> _Realized mix may differ from target — supply-bound sources "
            "(pes2o, jupyter at this scale) route their deficit to FineWeb_."
        )
        return "\n".join(lines)

    # Realized + target view. Compute per-source realized share from
    # the char totals in blend_stats.source_mix.
    source_mix = stats.get("source_mix", {})
    total_chars = sum(v.get("chars", 0) for v in source_mix.values())
    if total_chars == 0:
        # Defensive: shouldn't happen for a valid blend, but if chars sum
        # to zero we can't compute percentages — fall back to design-only
        # rather than print all zeros.
        log.warning("blend_stats.source_mix has zero total chars — using design targets only")
        return _format_data_mix_table_design_only()

    lines = [
        "| Source | Target Share | Realized Share | Link |",
        "|---|---|---|---|",
    ]

    # Top-level non-code sources from DATA_MIX, in declaration order.
    for name, entry in DATA_MIX.items():
        if name == "code":
            # Expand code into its sub-sources below, not as a single line.
            continue
        realized_chars = source_mix.get(name, {}).get("chars", 0)
        realized_pct = (realized_chars / total_chars) * 100
        lines.append(
            f"| `{name}` | {entry['pct']:.1f}% | {realized_pct:.2f}% | "
            f"{dataset_link(entry)} |"
        )

    # Code sub-sources, each as its own row. Their target % is
    # CODE_SUBMIX[name].pct of the current DATA_MIX['code'] share.
    code_top_pct = DATA_MIX["code"]["pct"]
    for name, entry in CODE_SUBMIX.items():
        target_pct_of_total = (entry["pct"] / 100.0) * code_top_pct
        realized_chars = source_mix.get(name, {}).get("chars", 0)
        realized_pct = (realized_chars / total_chars) * 100
        lines.append(
            f"| `{name}` | {target_pct_of_total:.2f}% | {realized_pct:.2f}% | "
            f"{dataset_link(entry)} |"
        )

    # Footer line summarising the realized totals so readers don't have
    # to add the column themselves.
    estimated_tokens = stats.get("estimated_tokens", 0)
    train_docs = stats.get("train_documents", 0)
    val_docs = stats.get("val_documents", 0)
    lines.append("")
    lines.append(
        f"_Realized: ~{estimated_tokens / 1e9:.2f}B tokens "
        f"({train_docs:,} train + {val_docs:,} val docs). "
        f"Supply-bound sources route their deficit to FineWeb._"
    )

    return "\n".join(lines)


def _format_data_mix_table_design_only() -> str:
    """
    Render the design target table with concrete source rows.

    DATA_MIX contains a logical "code" bucket, so expand that bucket into
    CODE_SUBMIX rows instead of showing a single abstract code row.
    """
    lines = [
        "| Source | Target Share | Link |",
        "|---|---|---|",
    ]

    for name, entry in DATA_MIX.items():
        if name == "code":
            code_top_pct = entry["pct"]
            for code_name, code_entry in CODE_SUBMIX.items():
                target_pct = (code_entry["pct"] / 100.0) * code_top_pct
                lines.append(
                    f"| `{code_name}` | {target_pct:.2f}% | "
                    f"{dataset_link(code_entry)} |"
                )
            continue

        lines.append(f"| `{name}` | {entry['pct']:.1f}% | {dataset_link(entry)} |")

    return "\n".join(lines)


def generate_model_card(
    size: str,
    variant: str,
    hub_name: str,
    n_params: int,
) -> str:
    size_upper    = size.upper()
    variant_cfg   = VARIANTS[variant]
    description   = variant_cfg["description"]
    pipeline_tag  = variant_cfg["pipeline_tag"]
    token_tgt     = corpus_tokens_display(size)
    param_str     = f"{n_params / 1e6:.1f}M ({n_params:,} parameters)"

    if variant == "base":
        base_model_yaml = ""
    elif variant in {"chat", "code"}:
        base_model_yaml = f"base_model: {HF_USERNAME}/slm-{size}-instruct"
    else:
        base_model_yaml = f"base_model: {HF_USERNAME}/slm-{size}"

    variant_section = {
        "base": f"""\
This is the **base** variant — pretrained from a {token_tgt} curation target with no fine-tuning.
It is suitable for research and as a starting point for further fine-tuning.
Use [`{HF_USERNAME}/slm-{size}-instruct`](https://huggingface.co/{HF_USERNAME}/slm-{size}-instruct) for instruction following or
[`{HF_USERNAME}/slm-{size}-chat`](https://huggingface.co/{HF_USERNAME}/slm-{size}-chat) for aligned conversation.
""",
        "instruct": f"""\
This is the **instruct** variant — the base model supervised fine-tuned on general chat and response-control instruction datasets.
It is the sibling base for both the general chat-DPO branch and the code-specialized branch.
Use [`{HF_USERNAME}/slm-{size}-chat`](https://huggingface.co/{HF_USERNAME}/slm-{size}-chat) for the DPO-aligned version preferred for open-ended conversation.
Use [`{HF_USERNAME}/slm-{size}`](https://huggingface.co/{HF_USERNAME}/slm-{size}) for the raw base model.
""",
        "chat": f"""\
This is the **chat** variant — the instruct model further aligned via general Direct Preference Optimization (DPO).
This is the recommended variant for conversational and assistant use cases.
Use [`{HF_USERNAME}/slm-{size}-instruct`](https://huggingface.co/{HF_USERNAME}/slm-{size}-instruct) for the SFT-only version.
Use [`{HF_USERNAME}/slm-{size}`](https://huggingface.co/{HF_USERNAME}/slm-{size}) for the raw base model.
""",
        "code": f"""\
This is the **code** variant — the instruct model further specialized with code SFT.
Use [`{HF_USERNAME}/slm-{size}-chat`](https://huggingface.co/{HF_USERNAME}/slm-{size}-chat) for general assistant use.
""",
    }[variant]

    pretrain_table = _format_data_mix_table(size)

    training_section = {
        "base": f"""\
**Pretraining corpus** — {token_tgt} curation target blended across the following sources:

{pretrain_table}
""",
        "instruct": f"""\
**Pretraining corpus** — {token_tgt} curation target blended across the following sources:

{pretrain_table}

**Fine-tuning**

| Stage | Dataset | Size |
|---|---|---|
| Instruct SFT | SmolTalk backbone + local response-control data | prepared by `finetune/data/prepare_sft.py` |
| Response control | Generated locally by `finetune/data/response_control.py` | local behavior-control examples |
""",
        "chat": f"""\
**Pretraining corpus** — {token_tgt} curation target blended across the following sources:

{pretrain_table}

**Fine-tuning and alignment**

| Stage | Dataset | Size |
|---|---|---|
| Instruct SFT | SmolTalk backbone + local response-control data | prepared by `finetune/data/prepare_sft.py` |
| Response control | Generated locally by `finetune/data/response_control.py` | local behavior-control examples |
| DPO alignment | [HuggingFaceH4/ultrafeedback_binarized](https://huggingface.co/datasets/HuggingFaceH4/ultrafeedback_binarized) + local general behavior pairs | prepared by `alignment/data/prepare_dpo.py` |
""",
        "code": f"""\
**Pretraining corpus** — {token_tgt} curation target blended across the following sources:

{pretrain_table}

**Fine-tuning**

| Stage | Dataset | Size |
|---|---|---|
| Instruct SFT | SmolTalk backbone + response-control | parent checkpoint: instruct |
| Code SFT | Magicoder-OSS-Instruct-75K + handcrafted body-only completions | code-specialized branch |
""",
    }[variant]

    return f"""---
license: mit
language:
  - en
pipeline_tag: {pipeline_tag}
tags:
  - causal-lm
  - decoder-only
  - custom-architecture
  - rope
  - gqa
  - swiglu
  - {variant}
{base_model_yaml}
---

# {hub_name}

A {size_upper} decoder-only language model ({description}). Part of the SLM model family —
built entirely from scratch, from raw web data through to a production-ready aligned model.

{variant_section}

## Model Family

| Variant | Hub | Description |
|---|---|---|
| Base | [{HF_USERNAME}/slm-{size}](https://huggingface.co/{HF_USERNAME}/slm-{size}) | Pretrained only |
| Instruct | [{HF_USERNAME}/slm-{size}-instruct](https://huggingface.co/{HF_USERNAME}/slm-{size}-instruct) | Instruct SFT + response-control |
| Chat | [{HF_USERNAME}/slm-{size}-chat](https://huggingface.co/{HF_USERNAME}/slm-{size}-chat) | Instruct + general DPO |

## Architecture

| Component | Choice | Rationale |
|---|---|---|
| Positional encoding | RoPE | Better length generalisation, relative position awareness |
| Normalization | RMSNorm | Faster than LayerNorm, modern standard |
| Activation | SwiGLU | Better gradient flow, used by LLaMA and Mistral |
| Attention | GQA | Reduces KV cache memory at inference |
| Bias | None | Simpler, modern standard |
| Embeddings | Tied | Reduces parameters, effective at small scale |
| Vocab size | 32,000 | Custom BPE tokenizer trained on the pretraining corpus |
| Parameters | {param_str} | |

## Training

{training_section}

**Hardware:** NVIDIA H200 (pretraining on 1× H200, fine-tuning on 1× H200)
## Usage

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained(
    "{HF_USERNAME}/{hub_name}",
    trust_remote_code=True,
)
tokenizer = AutoTokenizer.from_pretrained(
    "{HF_USERNAME}/{hub_name}",
    trust_remote_code=True,
)

messages = [
    {{"role": "system", "content": "Answer clearly and concisely."}},
    {{"role": "user", "content": "Explain what a transformer is."}},
]

inputs = tokenizer.apply_chat_template(
    messages,
    return_tensors="pt",
    add_generation_prompt=True,
    return_dict=True,
)

endofturn_id = tokenizer.convert_tokens_to_ids("<|endofturn|>")

output = model.generate(
    **inputs,
    max_new_tokens=120,
    do_sample=False,
    repetition_penalty=1.1,
    pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
    eos_token_id=[tokenizer.eos_token_id, endofturn_id],
)

input_len = inputs["input_ids"].shape[1]
print(tokenizer.decode(output[0][input_len:], skip_special_tokens=True))
```

`trust_remote_code=True` loads the custom SLM architecture bundled alongside the model weights — no local install of the `tohio/slm` codebase required.

## Limitations

- **Scale:** At {size_upper} parameters this model is significantly smaller than frontier models. It will underperform on complex reasoning, long-context tasks, and domains not well-represented in the pretraining data.
- **Hallucination:** Like all language models, this model can generate plausible-sounding but factually incorrect content. Outputs should not be used as a source of truth without independent verification.
- **Safety:** DPO alignment provides basic harmlessness training but does not guarantee safe outputs in all contexts. This model has not undergone red-teaming or adversarial safety evaluation.
- **Languages:** Training data is predominantly English. Performance on other languages will be significantly degraded.
- **Code:** Code generation is primarily Python-oriented, reflecting the code sub-mix distribution used in pretraining and SFT.

## Related

- [slm](https://github.com/tohio/slm) — full training pipeline (data curation through serving)
- [ai-infra](https://github.com/tohio/ai-infra) — production Kubernetes serving via vLLM
"""


def load_tokenizer(tokenizer_path: Path):
    """Load tokenizer via PreTrainedTokenizerFast — never reconstruct."""
    from transformers import PreTrainedTokenizerFast

    if not (tokenizer_path / "tokenizer_config.json").exists():
        raise FileNotFoundError(
            f"HuggingFace tokenizer not found at {tokenizer_path}. "
            f"Run: python tokenizer/train_tokenizer.py"
        )

    tokenizer = PreTrainedTokenizerFast.from_pretrained(str(tokenizer_path))

    if not getattr(tokenizer, "chat_template", None):
        raise ValueError(
            f"Tokenizer at {tokenizer_path} has no chat_template. "
            f"Retrain the tokenizer: python tokenizer/train_tokenizer.py"
        )

    return tokenizer



def _export_tokenizer_to_checkpoint_root(tokenizer, tokenizer_path: Path, checkpoint: Path) -> None:
    """
    Save/copy tokenizer artifacts to the checkpoint root so standard Hub loading works:

        AutoTokenizer.from_pretrained(repo_id, trust_remote_code=True)

    The tokenizer may also exist under checkpoint/tokenizer/, but the Hub root
    must contain tokenizer.json/tokenizer_config.json/etc. for normal use.
    """
    import shutil

    tokenizer.save_pretrained(str(checkpoint))

    for filename in [
        "tokenizer.json",
        "tokenizer_config.json",
        "vocab.json",
        "merges.txt",
        "special_tokens.json",
        "special_tokens_map.json",
        "chat_template.jinja",
        "slm_tokenizer.json",
    ]:
        src = tokenizer_path / filename
        dst = checkpoint / filename
        if src.exists():
            shutil.copy2(src, dst)
            log.info(f"Copied tokenizer artifact to checkpoint root: {filename}")

    special_tokens_map_path = checkpoint / "special_tokens_map.json"
    if not special_tokens_map_path.exists():
        special_tokens_map = {}
        for key, value in getattr(tokenizer, "special_tokens_map", {}).items():
            if isinstance(value, list):
                special_tokens_map[key] = [str(item) for item in value]
            else:
                special_tokens_map[key] = str(value)

        with special_tokens_map_path.open("w", encoding="utf-8") as f:
            json.dump(special_tokens_map, f, indent=2)
            f.write("\n")
        log.info("Created special_tokens_map.json from tokenizer.special_tokens_map")

    required = [
        "tokenizer.json",
        "tokenizer_config.json",
    ]
    missing = [name for name in required if not (checkpoint / name).is_file()]
    if missing:
        raise FileNotFoundError(
            f"Tokenizer export incomplete at checkpoint root. Missing: {missing}"
        )

    log.info("Tokenizer artifacts exported to checkpoint root")

def _bundle_remote_code_package(checkpoint: Path) -> Path:
    """
    Copy live architecture source files into the checkpoint root.

    Transformers remote-code auto_map should use entries like:
        config.SLMConfig
        model.SLMForCausalLM

    This root layout avoids nested auto_map values such as
    slm_remote.model.SLMForCausalLM, which are not accepted by some
    Transformers dynamic remote-code loaders.
    """
    import shutil

    for filename in BUNDLED_SOURCE_FILES:
        live_file = MODEL_PKG_DIR / filename
        if not live_file.is_file():
            raise FileNotFoundError(f"Missing live architecture source file: {live_file}")
        shutil.copy2(live_file, checkpoint / filename)

    log.info(
        f"Bundled remote-code files into checkpoint root "
        f"({len(BUNDLED_SOURCE_FILES)} files)"
    )
    return checkpoint

def _validate_bundled_files(checkpoint: Path) -> None:
    """
    Confirm bundled remote-code files at checkpoint root match live source.

    Existence alone is not enough — a stale bundled copy from an earlier
    export can ship buggy code to the Hub silently. Compare bytes against
    the live source to catch drift.
    """
    import hashlib

    missing, mismatched = [], []

    for filename in BUNDLED_SOURCE_FILES:
        ckpt_file = checkpoint / filename
        live_file = MODEL_PKG_DIR / filename

        if not ckpt_file.is_file():
            missing.append(filename)
            continue

        if hashlib.sha256(ckpt_file.read_bytes()).digest() != \
           hashlib.sha256(live_file.read_bytes()).digest():
            mismatched.append(filename)

    if missing:
        raise FileNotFoundError(
            f"Architecture files missing from checkpoint root: {missing}."
        )

    if mismatched:
        raise RuntimeError(
            f"Bundled architecture files differ from live source: {mismatched}. "
            f"Re-run export so checkpoint root files are refreshed."
        )

    log.info(
        f"Bundled remote code validated: "
        f"{len(BUNDLED_SOURCE_FILES)} root files match live source"
    )

def _ensure_remote_code_auto_map(checkpoint: Path) -> None:
    """
    Ensure config.json advertises the bundled custom architecture to
    Transformers AutoConfig / AutoModelForCausalLM.

    auto_map values use module.ClassName form for compatibility with
    Transformers dynamic remote-code loading.
    """
    config_path = checkpoint / "config.json"
    if not config_path.is_file():
        raise FileNotFoundError(f"Missing config.json at {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    expected_auto_map = {
        "AutoConfig": "config.SLMConfig",
        "AutoModelForCausalLM": "model.SLMForCausalLM",
    }

    current = cfg.get("auto_map")
    if current == expected_auto_map:
        log.info("Remote-code auto_map already present in config.json")
        return

    cfg["auto_map"] = expected_auto_map

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")

    log.info("Injected root remote-code auto_map into config.json")

def export(
    size: str,
    variant: str,
    model_path: Path | None = None,
    dry_run: bool = False,
    private: bool = False,
) -> None:
    from transformers import AutoConfig, AutoModelForCausalLM
    from huggingface_hub import login
    from model import SLMConfig, SLMForCausalLM

    if not HF_USERNAME:
        log.error(
            "HF_USERNAME not set in the environment. "
            "Add HF_USERNAME=<your-hub-username> to .env before running export."
        )
        sys.exit(1)

    variant_cfg = VARIANTS[variant]
    checkpoint  = model_path or variant_cfg["checkpoint"](size)
    hub_suffix  = variant_cfg["hub_suffix"]
    hub_name    = f"slm-{size}{hub_suffix}"
    repo_id     = f"{HF_USERNAME}/{hub_name}"

    log.info(f"=== SLM Export ===")
    log.info(f"Size:       {size}")
    log.info(f"Variant:    {variant}")
    log.info(f"Checkpoint: {checkpoint}")
    log.info(f"Hub:        {repo_id}")
    log.info(f"Dry run:    {dry_run}")

    if not checkpoint.exists():
        log.error(f"Checkpoint not found: {checkpoint}")
        log.error(
            f"Run the training pipeline first. For chat variant: "
            f"make pretrain sft-instruct sft-code dpo-chat SIZE={size}"
        )
        sys.exit(1)

    AutoConfig.register("slm", SLMConfig)
    AutoModelForCausalLM.register(SLMConfig, SLMForCausalLM)

    log.info("Loading model...")
    config   = SLMConfig.from_pretrained(str(checkpoint))
    model    = SLMForCausalLM.from_pretrained(str(checkpoint))
    n_params = sum(p.numel() for p in model.parameters())
    log.info(f"Parameters: {n_params:,} ({n_params / 1e6:.1f}M)")

    tokenizer_path = checkpoint / "tokenizer"
    if not (tokenizer_path / "tokenizer_config.json").exists():
        tokenizer_path = tokenizer_dir(size)
    tokenizer = load_tokenizer(tokenizer_path)
    log.info(f"Tokenizer loaded from {tokenizer_path}")

    _export_tokenizer_to_checkpoint_root(tokenizer, tokenizer_path, checkpoint)


    if dry_run:
        log.info("Dry run — skipping Hub push")
        log.info(f"Would push to: https://huggingface.co/{repo_id}")
        _validate_model(model, tokenizer, config)
        # Bundle and validate remote-code package before preview.
        _bundle_remote_code_package(checkpoint)
        _validate_bundled_files(checkpoint)
        _ensure_remote_code_auto_map(checkpoint)
        card = generate_model_card(size, variant, hub_name, n_params)
        log.info(f"Model card preview ({len(card):,} chars, first 400):")
        log.info(card[:400].replace("\n", "\n  "))
        return

    if not HF_TOKEN:
        log.error("HF_TOKEN not set in .env")
        sys.exit(1)
    login(token=HF_TOKEN)

    _validate_model(model, tokenizer, config)

    # Bundle and validate remote-code package before Hub upload.
    _bundle_remote_code_package(checkpoint)
    _validate_bundled_files(checkpoint)
    _ensure_remote_code_auto_map(checkpoint)

    model_card = generate_model_card(size, variant, hub_name, n_params)
    card_path  = checkpoint / "README.md"
    with open(card_path, "w") as f:
        f.write(model_card)
    log.info(f"Model card written to {card_path} ({len(model_card):,} chars)")

    # Single-commit push of the entire checkpoint dir — weights, config
    # (with auto_map), tokenizer, README.md, and the bundled remote-code package.
    # Using push_to_hub on the model would omit the README and any other
    # files at the checkpoint root, so we upload the folder directly.
    from huggingface_hub import HfApi

    api = HfApi(token=HF_TOKEN)
    api.create_repo(repo_id=repo_id, private=private, exist_ok=True)

    log.info(f"Pushing {checkpoint} to {repo_id} (single commit)...")
    api.upload_folder(
        repo_id=repo_id,
        folder_path=str(checkpoint),
        commit_message=f"Export {hub_name} ({n_params / 1e6:.1f}M params)",
        # Don't upload training-only artefacts even if they happen to be
        # in the checkpoint dir.
        ignore_patterns=[
            "optimizer.pt",
            "scheduler.pt",
            "trainer_state.json",
            "training_args.bin",
            "rng_state*.pth",
            "global_step*",
            "*.log",
            "__pycache__",
            "*.pyc",
        ],
    )

    log.info(f"Export complete: https://huggingface.co/{repo_id}")


def _too_repetitive(tokens: list[int], max_repeat_run: int = 8) -> bool:
    """Return True when generation contains an obvious repeated-token run.

    This is intentionally conservative: normal text can repeat words, but a
    healthy checkpoint should not emit the same token 8+ times in a row during
    a short export validation prompt. The check applies to every model size and
    variant as export hygiene, not just to 125M.
    """
    if not tokens:
        return True

    run = 1
    for prev, cur in zip(tokens, tokens[1:]):
        if cur == prev:
            run += 1
            if run >= max_repeat_run:
                return True
        else:
            run = 1

    return False


def _as_eos_id_list(eos_ids) -> list[int]:
    """Normalize an int/list/tuple EOS config to a clean list of IDs."""
    if eos_ids is None:
        return []
    if isinstance(eos_ids, int):
        return [eos_ids]
    return [int(eos_id) for eos_id in eos_ids if eos_id is not None]


def _validate_model(model, tokenizer, config) -> None:
    """Generate a short sequence and reject empty or degenerate output."""
    import torch
    from inference.utils import resolve_special_token_ids

    log.info("Validating model...")
    model.eval()
    special_ids = resolve_special_token_ids(tokenizer)

    messages = [
        {"role": "system", "content": "Answer clearly and concisely."},
        {"role": "user", "content": "What is the capital of France?"},
    ]
    input_ids = tokenizer.apply_chat_template(
        messages,
        return_tensors="pt",
        add_generation_prompt=True,
    )
    # apply_chat_template can return either a Tensor or a BatchEncoding
    # depending on transformers version / tokenizer config — normalize.
    if hasattr(input_ids, "input_ids"):
        input_ids = input_ids["input_ids"]
    attention_mask = torch.ones_like(input_ids)
    input_length = input_ids.shape[1]

    eos_ids = _as_eos_id_list(special_ids.eos_list)
    endofturn_id = tokenizer.convert_tokens_to_ids("<|endofturn|>")
    if isinstance(endofturn_id, int) and endofturn_id >= 0 and endofturn_id not in eos_ids:
        eos_ids.append(endofturn_id)

    with torch.no_grad():
        output = model.generate(
            input_ids,
            attention_mask=attention_mask,
            max_new_tokens=32,
            do_sample=False,
            repetition_penalty=1.1,
            pad_token_id=special_ids.pad,
            eos_token_id=eos_ids,
        )

    new_tokens = output[0][input_length:].tolist()
    for stop_id in eos_ids:
        if stop_id in new_tokens:
            new_tokens = new_tokens[: new_tokens.index(stop_id)]

    if len(new_tokens) == 0:
        raise RuntimeError(
            "Validation failed: model produced only stop tokens. "
            "This suggests the checkpoint is broken (e.g. NaN weights, "
            "wrong tied-weight restore, corrupted save). Aborting export."
        )

    decoded = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    if _too_repetitive(new_tokens):
        raise RuntimeError(
            "Validation failed: model produced highly repetitive output. "
            f"Decoded output: {decoded[:200]!r}"
        )

    log.info(f"Validation output ({len(new_tokens)} tokens): {decoded[:100]}")
    log.info("✓ Model validation passed")


def main():
    parser = argparse.ArgumentParser(
        description="Export SLM to HuggingFace Hub",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python export/export.py --size 125m --variant base
  python export/export.py --size 125m --variant instruct
  python export/export.py --size 125m --variant chat
  python export/export.py --size 125m --variant code
  python export/export.py --size 125m --variant chat --dry-run
        """,
    )
    parser.add_argument("--size",    type=str,  required=True, choices=["125m", "350m", "1b"])
    parser.add_argument(
        "--variant",
        type=str,
        required=True,
        choices=list(VARIANTS.keys()),
        help="base | instruct | chat | code",
    )
    parser.add_argument("--model",   type=Path, default=None,
                        help="Override checkpoint path (defaults to variant mapping)")
    parser.add_argument("--dry-run", action="store_true", help="Validate without pushing to Hub")
    parser.add_argument("--private", action="store_true", help="Create private Hub repository")
    args = parser.parse_args()

    export(
        size=args.size,
        variant=args.variant,
        model_path=args.model,
        dry_run=args.dry_run,
        private=args.private,
    )


if __name__ == "__main__":
    main()